<?php
global $user_identity;
$commenter = wp_get_current_commenter();
?>

<form class="bandit-form" action="<?php echo site_url( '/wp-comments-post.php' ); ?>" method="post" id="commentform">

	<header class="info"> 
		<h4><?php comment_form_title(bandit::get_lang('comments_form_title_add'),bandit::get_lang('comments_form_title_reply')); ?></h4>
		<?php cancel_comment_reply_link(bandit::get_lang('comments_form_cancel_reply')); ?>

<?php if (is_user_logged_in()): ?>
		<div>Logged in as <a href="<?php echo admin_url('profile.php'); ?>"><?php echo $user_identity; ?></a></div>
	</header>

	<ul>
<?php else: ?>
	</header>

	<ul>
		<li class="leftThird">
			<label for="author" class="desc"><?php bandit::lang('comments_form_name'); ?>
				<span class="req">*</span>
			</label>
			<div>
				<input type="text" name="author" value="<?php echo esc_attr($commenter['comment_author']); ?>" id="author" class="field text medium">
			</div>
		</li>

		<li class="middleThird">
			<label for="email" class="desc"><?php bandit::lang('comments_form_email'); ?>
				<span class="req">*</span>
			</label>
			<div>
				<input type="text" name="email" value="<?php echo esc_attr($commenter['comment_author_email']); ?>" id="email" class="field text medium">
			</div>
		</li>

		<li class="rightThird">
			<label for="url" class="desc"><?php bandit::lang('comments_form_website'); ?></label>
			<div>
				<input type="text" name="url" value="<?php echo esc_attr($commenter['comment_author_url']); ?>" id="url" class="field text medium">
			</div>
		</li>
<?php endif; ?>

		<li>
			<label for="comment" class="desc"><?php bandit::lang('comments_form_comment'); ?></label>
			<div>
				<textarea name="comment" id="comment" cols="50" rows="10" class="field textarea medium"></textarea>
			</div>
		</li>

		<li class="buttons">
			<div>
				<input id="saveForm" name="saveForm" class="btTxt submit" type="submit" value="Submit" />
			</div>
		</li>
	</ul>

<?php comment_id_fields(); ?>
<?php do_action('comment_form', $post->ID); ?>
</form>