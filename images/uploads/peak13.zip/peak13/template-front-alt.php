<?php
/*
Template Name: Front Page (Alternate)
*/

$meta=get_post_custom($post->ID);
?>

<?php get_header(); ?>

<div id="content" class="t-front">
<?php if(isset($meta['_bandit_front_intro_top'])): // FRONT INTRO TOP ?>
	<div id="topintro">
		<div id="topintro_inner" class="container_12 clearfix">
			<div class="grid_12">
				<h2><?php echo $meta['_bandit_front_intro_top'][0]; ?></h2>
			</div>
		</div>
	</div>
<?php endif; // END FRONT INTRO TOP ?>


<?php if(isset($meta['_bandit_front_slider_count'])): // CONTENT SLIDER BLOCK ?>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$("#front-slider").slides({
			autoHeight: false,
			preload: true,
			generatePagination: false,
			effect: 'fade',
			crossfade: true,
			play: 10000
		});
	});
</script>

	<div id="topline">
		<div id="topline_inner" class="container_12 clearfix">
			<div class="grid_12 front-slider">
			
			<!--video+text block-->
			<div id="front-slider" class="video">		
				<div id="slider-prev" class="prev">Previous</div>
				<div id="slider-next" class="next">Next</div>
				<div class="slides_container">

<?php for($i=1;$i<=$meta['_bandit_front_slider_count'][0];$i++): ?>
					<div class="item">
						<div class="left">
							<div class="item-img">
								<div class="outer-center">
									<div class="inner-center">
<?php
	if(isset($meta['_bandit_front_slider_image_url'.$i][0])) {
		echo '<img src="'.$meta['_bandit_front_slider_image_url'.$i][0].'" width="560" alt="image-'.$i.'" />';
	} elseif(isset($meta['_bandit_front_slider_video_url'.$i][0])) {
		global $wp_embed;
		$video = $wp_embed->run_shortcode('[embed width="560" height="315"]'.$meta['_bandit_front_slider_video_url'.$i][0].'[/embed]');
		echo $video;
	} elseif(isset($meta['_bandit_front_slider_video_embed'.$i][0])) {
		echo $meta['_bandit_front_slider_video_embed'.$i][0];
	}
?>
									</div>
								</div>
							</div>
						</div>
						<div class="right">
							<h2><?php echo $meta['_bandit_front_slider_title'.$i][0]; ?></h2>
							<div class="text">
								<p><?php echo $meta['_bandit_front_slider_content'.$i][0]; ?></p>
								
							<?php if(isset($meta['_bandit_front_slider_button_link'.$i][0])): ?>
								<div class="clear"></div>
								<a class="more" href="<?php echo $meta['_bandit_front_slider_button_link'.$i][0]; ?>">
									<?php echo $meta['_bandit_front_slider_button_text'.$i][0]; ?>
								</a>
							<?php endif; ?>
							</div>
						</div>
					</div>
<?php endfor; ?>

				</div>
				<div id="shadow">
					<ul class="pagination">
						<?php for($j=1;$j<=$meta['_bandit_front_slider_count'][0];$j++): ?>
							<li><a href="#"><?php echo $j; ?></a></li>
						<?php endfor; ?>
					</ul>
				</div>
			</div>


			</div>
		</div>
	</div>
<?php endif; // END CONTENT SLIDER BLOCK ?>

	<div id="content_inner" class="container_12 clearfix">
		
<?php if(isset($meta['_bandit_front_intro_bottom'])): // FRONT INTRO BOTTOM ?>
		<div class="grid_12" id="bottomintro_inner">
			<h2><?php echo $meta['_bandit_front_intro_bottom'][0]; ?></h2>
		</div>
<?php endif; // END FRONT INTRO BOTTOM ?>


<?php if(!isset($meta['_bandit_front_content_disable'])): // CONTENT BLOCK ?>
<?php if(isset($meta['_bandit_front_content_title'][0])): // CONTENT BLOCK TITLE ?>
		<div class="grid_12">
			<h4 class="dotted">
				<span><?php echo $meta['_bandit_front_content_title'][0]; ?></span>
			</h4>
		</div>
<?php endif; // END CONTENT BLOCK TITLE ?>

		<div id="front-blocks" class="clearfix">
<?php for($i=1;$i<=6;$i++): // CONTENT ITEMS ?>
<?php if(isset($meta['_bandit_front_content_block'.$i])): ?>
			<div class="grid_4">
				<?php echo $meta['_bandit_front_content_block'.$i][0]; ?>
			</div>
<?php endif; ?>
<?php endfor; // END CONTENT ITEMS ?>
		</div>
<?php endif; // END CONTENT BLOCK ?>


<?php if(!isset($meta['_bandit_front_portfolio_disable'])): // PORTFOLIO BLOCK ?>
		<div class="grid_12">
			<div id="front-btnblock" class="clearfix">
				<div>
					<h3><?php echo $meta['_bandit_front_portfolio_title'][0]; ?></h3>
					<p><?php echo $meta['_bandit_front_portfolio_desc'][0]; ?></p>
				</div>
				<a class="button-large" href="<?php if(isset($meta['_bandit_front_portfolio_link'][0])) { echo $meta['_bandit_front_portfolio_link'][0]; } ?>">
					<?php echo $meta['_bandit_front_portfolio_link_text'][0]; ?>
				</a>
			</div>
		</div>
<?php endif; // END PORTFOLIO BLOCK ?>


<?php if($meta['_bandit_front_blog_num'][0]!='none'): // BLOG BLOCK ?>
<?php if(isset($meta['_bandit_front_blog_title'][0])): ?>
		<div class="grid_12">
			<h4 class="dotted">
				<span><?php echo $meta['_bandit_front_blog_title'][0]; ?></span>
			</h4>
		</div>
<?php endif;?>

		<div class="grid_12">
<?php 
	// Blog loop
	$blog=new WP_Query(array('posts_per_page'=>$meta['_bandit_front_blog_num'][0],'ignore_sticky_posts'=>1));
	// Blog counter
	$blogcount=1;
	// Loop through posts
	while($blog->have_posts()): $blog->the_post();
		// Post class
		$blogpostclass='';
		if((($blogcount-1)%3)==0)
			$blogpostclass=' alpha';
		elseif(($blogcount%3)==0)
			$blogpostclass=' omega';
?>
			<div class="grid_4<?php echo $blogpostclass; ?>">
				<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
					<div class="format-icon">
						<i class="icon"></i>
					</div>
					<header>
						<h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					</header>
					<ul class="entry-meta clearfix">
						<li class="published"><a href="<?php the_permalink(); ?>" title="Permalink for: <?php the_title(); ?>"><i class="icon"></i><?php bandit::time_ago(); ?></a></li>
						<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
							<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
						</li>
						<li class="comment-count"><a href="<?php comments_link(); ?>"><i class="icon"></i><?php comments_number('0','1','%'); ?></a></li>
					</ul>	
				</article>	
			</div>
<?php $blogcount++; ?>
<?php endwhile; ?>
		</div>
<?php endif; // END BLOG BLOCK ?>

	</div>
</div>

<?php get_footer(); ?>