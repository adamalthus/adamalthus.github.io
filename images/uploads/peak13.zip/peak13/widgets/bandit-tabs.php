<?php

/**
	Widget Name

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package WidgetName
		@version 1.0
**/

class Bandit_Tabs extends WP_Widget {

	/**
		Constructor
	**/
	function Bandit_Tabs() {
		parent::WP_Widget(false,$name='Bandit Tabbed Widget');	
	}

	/**
		Widget
	**/
	function widget($args, $instance) {
		extract( $args );
		$instance['title']?NULL:$instance['title']='';
		$title = apply_filters('widget_title',$instance['title']);
		$tab_post_thumbnails = $instance['tab_post_thumbnails'];
		$tab_popular_title = $instance['tab_popular_title'];
		$tab_recent_title = $instance['tab_recent_title'];
		$tab_comments_title = $instance['tab_comments_title'];
		$tab_tags_title = $instance['tab_tags_title'];
		$output=$before_widget."\n";
		if($title)
			$output.=$before_title.$title.$after_title;
		ob_start();
?>

<div class="bandit_tabs">
	<ul class="tab-links clearfix">
		<li id="bandit-tab1"><a href="#tabs-1"><?php echo $tab_popular_title; ?></a></li>
		<li id="bandit-tab2"><a href="#tabs-2"><?php echo $tab_recent_title; ?></a></li>
		<li id="bandit-tab3"><a href="#tabs-3"><?php echo $tab_comments_title; ?></a></li>
		<li id="bandit-tab4"><a href="#tabs-4"><?php echo $tab_tags_title; ?></a></li>
	</ul>

	<div class="bandit_tabs_inner">

<?php $popular=new WP_Query(); ?>
<?php $popular->query('showposts=5&ignore_sticky_posts=1&orderby=comment_count'); ?>
		<div id="tabs-1" class="bandit_tab">
			<ul class="clearfix">
<?php while ($popular->have_posts()): $popular->the_post(); ?>
<?php $image_id=get_post_thumbnail_id(); ?>
<?php if($image_id) { $image=bandit::dynamic_resize($image_id,'','50','50',TRUE); } ?>
				<li>
					<?php if($tab_post_thumbnails && has_post_thumbnail()): ?>
					<div class="tab-entry-image"><img src="<?php echo $image['url']; ?>" width="50" height="50" ></div>
					<?php endif; ?>
					<p class="tab-entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
					<p class="tab-entry-date"><?php the_time('F j, Y'); ?></p>
				</li>
<?php endwhile; ?>
			</ul>
		</div>

<?php $recent=new WP_Query(); ?>
<?php $recent->query('showposts=5&ignore_sticky_posts=1');?>
		<div id="tabs-2" class="bandit_tab">
			<ul class="clearfix">
<?php while ($recent->have_posts()): $recent->the_post(); ?>
<?php $image_id=get_post_thumbnail_id(); ?>
<?php if($image_id) { $image=bandit::dynamic_resize($image_id,'','50','50',TRUE); } ?>
				<li>
					<?php if($tab_post_thumbnails && has_post_thumbnail()): ?>
					<div class="tab-entry-image"><img src="<?php echo $image['url']; ?>" width="50" height="50" ></div>
					<?php endif; ?>
					<p class="tab-entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
					<p class="tab-entry-date"><?php the_time('F j, Y'); ?></p>
				</li>
<?php endwhile; ?>
			</ul>
		</div>

<?php $comments=get_comments(array('number'=>5,'status'=>'approve','post_status'=>'publish')); ?>
		<div id="tabs-3" class="bandit_tab bandit_tab_comments">
			<ul class="clearfix">
<?php foreach ($comments as $comment): ?>
				<li class="clearfix">
					<div class="avatar"><?php echo get_avatar($comment->comment_author_email,$size='50'); ?></div>
					<div class="comment_wrap">
<?php
$str=explode(' ',get_comment_excerpt($comment->comment_ID));
$comment_excerpt=implode(' ',array_slice($str,0,11));
if(count($str) > 11 && substr($comment_excerpt,-1)!='.')
	$comment_excerpt.=' ...'
?>
						<p><a class="comment_link" href="<?php echo esc_url(get_comment_link($comment->comment_ID)); ?>"><span><?php echo $comment->comment_author; ?>:</span> <?php echo $comment_excerpt; ?></a></p>
					</div>
				</li>
<?php endforeach; ?>
			</ul>
		</div>

			<div id="tabs-4" class="bandit_tab">
				<div class="bandit_tab bandit_tab_tagcloud">
					<?php wp_tag_cloud(); ?>
				</div>
			</div>
	</div>
</div>

<?php
		$output.=ob_get_clean();
		$output.=$after_widget."\n";
		echo $output;
	}

	/**
		Widget update
	**/
	function update($new_instance,$old_instance) {
		$instance=$old_instance;
		$instance['title']=strip_tags($new_instance['title']);
		$instance['tab_post_thumbnails']=$new_instance['tab_post_thumbnails']?1:0;
		$instance['tab_popular_title']=strip_tags($new_instance['tab_popular_title']);
		$instance['tab_recent_title']=strip_tags($new_instance['tab_recent_title']);
		$instance['tab_comments_title']=strip_tags($new_instance['tab_comments_title']);
		$instance['tab_tags_title']=strip_tags($new_instance['tab_tags_title']);
		return $instance;
	}

	/**
		Widget form
	**/
	function form($instance) {
		// Default widget settings
		$defaults = array(
			'title'=>__(''),
			'tab_post_thumbnails'=>0,
			'tab_popular_title'=>__('Popular'),
			'tab_recent_title'=>__('Recent'),
			'tab_comments_title'=>__('Comments'),
			'tab_tags_title'=>__('Tags'),
		);
		$instance = wp_parse_args( (array) $instance, $defaults );
		$thumbnails = $instance['tab_post_thumbnails']?' checked="checked"':'';
		// Build form
		$form='<p>';
		$form.='<label for="'.$this->get_field_id('title').'">Title <small>(recommended - leave blank)</small>:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.$instance['title'].'" />';
		$form.='</p>';

		$form.='<p>';
		$form.='<input class="checkbox" id="'.$this->get_field_id('tab_post_thumbnails').'" name="'.$this->get_field_name('tab_post_thumbnails').'" type="checkbox"'.$thumbnails.'>';
		$form.=' <label for="'.$this->get_field_id('tab_post_thumbnails').'">Show Post Thumbnails</label>';
		$form.='</p>';
		
		$form.='<p>';
		$form.='<label for="'.$this->get_field_id('tab_popular_title').'">Popular Posts Tab Title:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('tab_popular_title').'" name="'.$this->get_field_name('tab_popular_title').'" type="text" value="'.$instance['tab_popular_title'].'" />';
		$form.='</p>';

		$form.='<p>';
		$form.='<label for="'.$this->get_field_id('tab_recent_title').'">Recent Posts Tab Title:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('tab_recent_title').'" name="'.$this->get_field_name('tab_recent_title').'" type="text" value="'.$instance['tab_recent_title'].'" />';
		$form.='</p>';

		$form.='<p>';
		$form.='<label for="'.$this->get_field_id('tab_comments_title').'">Comments Tab Title:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('tab_comments_title').'" name="'.$this->get_field_name('tab_comments_title').'" type="text" value="'.$instance['tab_comments_title'].'" />';
		$form.='</p>';

		$form.='<p>';
		$form.='<label for="'.$this->get_field_id('tab_tags_title').'">Tags Tab Title:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('tab_tags_title').'" name="'.$this->get_field_name('tab_tags_title').'" type="text" value="'.$instance['tab_tags_title'].'" />';
		$form.='</p>';
		// Display form
		echo $form;
	}

}