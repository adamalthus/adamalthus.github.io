<?php

/**
	Flickr widget for the Bandit Framework

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package Bandit_Flickr
		@version 1.3.0
**/

//! Flickr widget
class Bandit_Flickr extends WP_Widget {

	/**
		Constructor
	**/
	function Bandit_Flickr() {
		parent::WP_Widget(false,$name='Bandit Flickr');	
	}

	/**
		Widget
	**/
	function widget($args, $instance) {
		extract( $args );
		$instance['title']?NULL:$instance['title']='Photos';
		$title = apply_filters('widget_title',$instance['title']);
		$flickr_id = $instance['flickr_id'];
		$flickr_num_photos = $instance['flickr_num_photos'];
		$output=$before_widget."\n";
		$output.=$before_title.$title.$after_title;
		if ($flickr_id) {
			$output.='<div id="flickr_wrap" class="clearfix">';
			$output.='<script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count='.$flickr_num_photos.'&amp;display=latest&amp;size=s&amp;layout=x&amp;source=user&amp;user='.$flickr_id.'"></script>';
			$output.='</div>';
		}
		$output.=$after_widget."\n";
		echo $output;
	}


	/**
		Widget update
	**/
	function update($new_instance,$old_instance) {
		$instance=$old_instance;
		$instance['title']=strip_tags($new_instance['title']);
		$instance['flickr_id']=strip_tags($new_instance['flickr_id']);
		$instance['flickr_num_photos']=strip_tags($new_instance['flickr_num_photos']);
		return $instance;
	}

	/**
		Widget form
	**/
	function form($instance) {
		// Default widget settings
		$defaults = array( 'title' => __('Photos'), 'flickr_num_photos'=>2 );
		$instance = wp_parse_args( (array) $instance, $defaults );
		// Build form
		$form='<p>'."\n";
		$form.='<label for="'.$this->get_field_id('title').'">Title:</label>'."\n";
		$form.='<input class="widefat" id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.$instance['title'].'" />'."\n";
		$form.='</p>'."\n";

		$form.='<p>'."\n";
		$form.='<label for="'.$this->get_field_id('flickr_id').'">'.__('Flickr ID:','bandit').'</label>'."\n";
		$form.='<input id="'.$this->get_field_id('flickr_id').'" name="'.$this->get_field_name('flickr_id').'" value="'.$instance['flickr_id'].'" type="text" class="widefat" />'."\n";
		$form.='</p>'."\n";

		$form.='<p>'."\n";
		$form.='<label for="'.$this->get_field_id('flickr_num_photos').'">'.__('# of Photos:','bandit').'</label>'."\n";
		$form.='<select id="'.$this->get_field_id('flickr_num_photos').'" name="'.$this->get_field_name('flickr_num_photos').'">';
		for($i=1;$i<13;$i++)
			$form.='<option value="'.$i.'" '.(($instance['flickr_num_photos']==$i)?'selected="selected"':NULL).'>'.$i.'</option>';
		$form.='</select>';
		$form.='</p>'."\n";

		// Display form
		echo $form;
	}

}