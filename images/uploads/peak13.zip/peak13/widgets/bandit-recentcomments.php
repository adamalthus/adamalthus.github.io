<?php

/**
	Recent comments widget for the Bandit Framework

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package Bandit_RecentComments
		@version 1.1
**/

//! Recent comments widget
class Bandit_RecentComments extends WP_Widget {

	/**
		Constructor
	**/
	function Bandit_RecentComments() {
		parent::WP_Widget(false,$name='Bandit Recent Comments');	
	}

	/**
		Widget
	**/
	function widget($args, $instance) {
		extract( $args );
		$instance['title']?NULL:$instance['title']='Recent Comments';
		$title=apply_filters('widget_title',$instance['title']);
		$comments_num=$instance['comments_num'];
		$output=$before_widget."\n";
		$output.=$before_title.$title.$after_title;
		if($comments_num) {
			// Get comments
			$comments=get_comments(array('number'=>$comments_num,'status'=>'approve','post_status'=>'publish'));
			// Build widget
			$output.='<ul class="clearfix">'."\n";
			foreach ($comments as $comment) {
				// Reduce comment excerpt length
				$str=explode(' ',get_comment_excerpt($comment->comment_ID));
				$comment_excerpt=implode(' ',array_slice($str,0,10));
				if(count($str) > 10 && substr($comment_excerpt,-1)!='.')
					$comment_excerpt.=' ...';
				// Output comment
				$output.='<li>'."\n";
				$output.='<div class="gravatar">'.get_avatar($comment->comment_author_email,$size='50')."\n";
				$output.='	<a class="view_more" href="'.esc_url(get_comment_link($comment->comment_ID)).'">Discuss</a>'."\n";
				$output.='</div>'."\n";
				$output.='<div class="wrap_comment">'."\n";
				$output.='	<div class="post_link">in <span>'.get_the_title($comment->comment_post_ID).'</span></div>'."\n";
				$output.='	<p>by '.$comment->comment_author.'</p>'."\n";
				$output.='	<a class="comment_link" href="'.esc_url(get_comment_link($comment->comment_ID)).'">"'.$comment_excerpt.'"</a>'."\n";
				$output.='</div>'."\n";
				$output.='</li>'."\n";
			}
		}
		$output.='</ul>'."\n";
		$output.=$after_widget."\n";
		echo $output;
	}


	/**
		Widget update
	**/
	function update($new_instance,$old_instance) {
		$instance=$old_instance;
		$instance['title']=strip_tags($new_instance['title']);
		$instance['comments_num']=strip_tags($new_instance['comments_num']);
		return $instance;
	}

	/**
		Widget form
	**/
	function form($instance) {
		// Default widget settings
		$defaults=array('title'=>__('Recent Comments'),'comments_num'=>2);
		$instance=wp_parse_args((array)$instance,$defaults);
		// Build form
		$form='<p>';
		$form.='<label for="'.$this->get_field_id('title').'">Title:</label>';
		$form.='<input class="widefat" id="'.$this->get_field_id('title').'" name="'.$this->get_field_name('title').'" type="text" value="'.$instance['title'].'" />';
		$form.='</p>';

		$form.='<p>';
		$form.='<label for="'.$this->get_field_id('comments_num').'">'.__('# of Comments:').'</label>';
		$form.='<select id="'.$this->get_field_id('comments_num').'" name="'.$this->get_field_name('comments_num').'">';
		for($i=1;$i<5;$i++)
			$form.='<option value="'.$i.'" '.(($instance['comments_num']==$i)?'selected="selected"':NULL).'>'.$i.'</option>';
		$form.='</select>';
		$form.='</p>';
		// Display form
		echo $form;
	}

}