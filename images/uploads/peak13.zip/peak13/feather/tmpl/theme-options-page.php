<div class="wrap">
<?php
// Print tabs
FeatherAdmin::print_options_page_tabs('theme');
// Get current tab
$tab=FeatherAdmin::get_current_options_page_tab('theme');
// Set settings field and tab option
if('language'==$tab) {
	$settings='bandit_language';
} else {
	$settings='bandit_theme';
}
// If theme tab settings updated, flush rewrite rules
if(isset($_GET['settings-updated']) && ('theme'==$tab)) {
	flush_rewrite_rules();
}
?>
<div class="feather postbox">
	<form action="options.php" method="post">
		<?php settings_fields($settings.'-settings'); ?>
		<?php do_settings_sections($settings.'-'.$tab); ?>

		<input type="hidden" name="<?php echo $settings; ?>[tab]" value="<?php echo $tab; ?>">

		<p class="submit">
			<input type="submit" class="button-primary" value="Save Changes" />

<?php if('language'==$tab) {
	echo '<input name="bandit_language[reset]" onClick="return confirm(\'Are you sure you want to reset language settings?\');" type="submit" class="button-secondary" value="Reset To Defaults" />';
} ?>
		</p>
	</form>
	<p id="wpbandit">Feather created by <a href="http://wpbandit.com/">WPBandit</a></p>
</div>
</div>