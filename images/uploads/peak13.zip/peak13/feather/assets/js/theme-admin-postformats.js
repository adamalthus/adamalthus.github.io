var $b = jQuery.noConflict();

$b(document).ready(function() {

	// Hide Post Format Sections
	$b('#bandit_format_audio,#bandit_format_link,#bandit_format_quote,#bandit_format_video').hide();

	// Supported post formats
	var post_formats = ['audio','link','quote','video'];

	// Get selected post format
	var selected_post_format = $b("input[name='post_format']:checked").val();

	// Show post format meta box
	if(jQuery.inArray(selected_post_format,post_formats) != -1) {
		$b('#bandit_format_'+selected_post_format).show();
	}

	// Hide/show post format meta box when option changed
	$b("input[name='post_format']:radio").change(function() {
		$b('#bandit_format_audio,#bandit_format_link,#bandit_format_quote,#bandit_format_video').hide();
		if(jQuery.inArray($b(this).val(),post_formats) != -1) {
			$b('#bandit_format_'+$b(this).val()).show();
		}
	});

});