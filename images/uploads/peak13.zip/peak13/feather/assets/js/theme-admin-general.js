var $b = jQuery.noConflict();

$b(document).ready(function() {

	// Define namespace
	feather={};

	// Set image field; Show media library
	$b('.feather-image-button').click(function() {
		feather.image_field = $b(this).siblings('input[type="text"]').attr('name');
		feather.img_field_id = $b(this).attr('data-id');
		tb_show('','media-upload.php?type=image&TB_iframe=true');
		return false;
	});

	// Populate image field with URL; Remove media library
	window.send_to_editor = function(html) {
		var feather_img_url = $b('img',html).attr('src');
		$b('input[name="'+feather.image_field+'"]').val(feather_img_url);
		$b('#feather_'+feather.img_field_id+'_placeholder').html('<img src="'+feather_img_url+'" width="41" height="41" />');
		tb_remove();
	}

});