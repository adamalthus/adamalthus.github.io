<?php

/*---------------------------------------------------------------------------*
 * Peak Meta Configuration
 *---------------------------------------------------------------------------*/

/* ---- Front Templates ---------------------------------------------------- */

//! Intro Top
$meta['peak_front_top']=array(
	'title'=>'Intro - Top',
	'page'=>'page',
	'template'=>array('template-front.php','template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_intro_top',
			'label'=>'Text',
			'type'=>'textarea',
			'rows'=>'5',
			'disable_editor'=>TRUE
		),
	)
);

//! Slider (Front Only)
$meta['peak_front_slider']=array(
	'title'=>'Slider',
	'page'=>'page',
	'template'=>array('template-front.php'),
	'context'=>'normal',
	'priority'=>'high',
	'callback'=>'FeatherTheme::front_slider_meta'
);

//! Slider Count (Alternate Only)
$meta['peak_front_slider_count']=array(
	'title'=>'Content Slider Count',
	'page'=>'page',
	'template'=>array('template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_slider_count',
			'label'=>'# of Content Slider Items',
			'type'=>'select',
			'std'=>'',
			'options'=>array(
				'0'=>'Disable',
				'1'=>'1',
				'2'=>'2',
				'3'=>'3',
				'4'=>'4',
				'5'=>'5',
				'6'=>'6'
			)
			
		)
	)
);

//! Content Slider (Alternate Only)
$meta['peak_front_slider_content']=array(
	'title'=>'Content Slider',
	'page'=>'page',
	'template'=>array('template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'count'=>6,
	'args'=>array(
		array(
			'id'=>'_bandit_front_slider_title',
			'label'=>'Title',
			'type'=>'text',
			'std'=>''
		),
		array(
			'id'=>'_bandit_front_slider_content',
			'label'=>'Content',
			'type'=>'textarea',
			'rows'=>'4'
		),
		array(
			'id'=>'_bandit_front_slider_button_text',
			'label'=>'Button Text',
			'type'=>'text',
			'std'=>''
		),
		array(
			'id'=>'_bandit_front_slider_button_link',
			'label'=>'Button Link (URL)',
			'type'=>'text',
			'std'=>''
		),
		array(
			'id'=>'_bandit_front_slider_video_url',
			'label'=>'Video URL (Recommended)',
			'type'=>'text',
			'std'=>''
		),
		array(
			'id'=>'_bandit_front_slider_video_embed',
			'label'=>'Video Embed Code',
			'type'=>'textarea',
			'rows'=>'4',
			'std'=>''
		),
		array(
			'id'=>'_bandit_front_slider_image_url',
			'label'=>'Image URL <small><strong>(560x315px)</strong></small>',
			'type'=>'text',
			'std'=>''
		)
	)
);

//! Intro Bottom
$meta['peak_front_bottom']=array(
	'title'=>'Intro - Bottom',
	'page'=>'page',
	'template'=>array('template-front.php','template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_intro_bottom',
			'label'=>'Text',
			'type'=>'textarea',
			'rows'=>'5'
		),
	)
);

//! Portfolio Link
$meta['peak_front_portfolio_link']=array(
	'title'=>'Portfolio Section',
	'page'=>'page',
	'template'=>array('template-front.php','template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_portfolio_title',
			'label'=>'Title',
			'type'=>'text',
			'std'=>'View more of our work. Get inspired.'
		),
		array(
			'id'=>'_bandit_front_portfolio_desc',
			'label'=>'Description',
			'type'=>'text',
			'std'=>'Browse and view some of the things we\'ve made'
		),
		array(
			'id'=>'_bandit_front_portfolio_link_text',
			'label'=>'Button Text',
			'type'=>'text',
			'std'=>'View Portfolio'
		),
		array(
			'id'=>'_bandit_front_portfolio_link',
			'label'=>'Button Link (URL)',
			'type'=>'text',
			'std'=>'#'
		),
		array(
			'id'=>'_bandit_front_portfolio_disable',
			'label'=>'Disable Portfolio Section',
			'type'=>'checkbox'
		)
	)
);

//! Blog
$meta['peak_front_blog']=array(
	'title'=>'Blog Section',
	'page'=>'page',
	'template'=>array('template-front.php','template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_blog_title',
			'label'=>'Title',
			'type'=>'text',
			'std'=>'',
		),
		array(
			'id'=>'_bandit_front_blog_num',
			'label'=>'# of Posts',
			'type'=>'select',
			'std'=>'3',
			'options'=>array(
				'none'=>'Disable',
				'3'=>'3',
				'6'=>'6',
				'9'=>'9'
			)
		),
	)
);

//! Content
$meta['peak_front_content']=array(
	'title'=>'Content Section',
	'page'=>'page',
	'template'=>array('template-front.php','template-front-alt.php'),
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_front_content_title',
			'label'=>'Title',
			'type'=>'text',
			'std'=>'',
		),
		array(
			'id'=>'_bandit_front_content_block',
			'label'=>'Block',
			'type'=>'textarea',
			'rows'=>'7',
			'count'=>6,
		)
	)
);

/* ---- Portfolio Post Template -------------------------------------------- */

$meta['peak_portfolio']=array(
	'title'=>'Portfolio Post Template',
	'page'=>'portfolio',
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		// Portfolio Template
		array(
			'id'=>'_bandit_portfolio_template',
			'label'=>'Template',
			'type'=>'select',
			'std'=>'',
			'options'=>array(
				'1'=>'Template 1',
				'2'=>'Template 2',
				'3'=>'Template 3'
			),
		),
		// Portfolio Video Template
		array(
			'id'=>'_bandit_portfolio_video_template',
			'label'=>'Video Template',
			'type'=>'checkbox',
			'choices'=>array(
				'portfolio_video_template'=>'Enable Video Template'
			)
		)
	)
);

/* ---- Portfolio Post TimThumb -------------------------------------------- */

$meta['peak_portfolio_timthumb']=array(
	'title'=>'Portfolio Thumbnail Alternative (optional)',
	'page'=>'portfolio',
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_portfolio_timthumb',
			'label'=>'Use TimThumb for thumbnail',
			'type'=>'checkbox'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_sharpen',
			'label'=>'Sharpen Image (optional)',
			'type'=>'checkbox'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_greyscale',
			'label'=>'Greyscale (optional)',
			'type'=>'checkbox'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_quality',
			'label'=>'Image Quality (optional)',
			'type'=>'text',
			'class'=>'small-text'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_brightness',
			'label'=>'Image Brightness (optional)',
			'type'=>'text',
			'class'=>'small-text'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_contrast',
			'label'=>'Image Contrast (optional)',
			'type'=>'text',
			'class'=>'small-text'
		),
		array(
			'id'=>'_bandit_portfolio_timthumb_crop',
			'label'=>'Crop Direction',
			'type'=>'select',
			'std'=>'',
			'options'=>array(
				'c'=>'Center',
				't'=>'Top',
				'tl'=>'Top Left',
				'tr'=>'Top Right',
				'b'=>'Bottom',
				'bl'=>'Bottom Left',
				'br'=>'Bottom Right',
				'l'=>'Left',
				'r'=>'Right'
			)
		)
	)
);

/* ---- Portfolio Custom Thumbnail ----------------------------------------- */

$meta['peak_portfolio_custom_thumbnail']=array(
	'title'=>'Portfolio Custom Thumbnail',
	'page'=>'portfolio',
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_portfolio_custom_thumbnail',
			'label'=>'Image URL',
			'type'=>'text'
		)
	)
);

/* ---- Portfolio Video ---------------------------------------------------- */

$meta['peak_portfolio_video']=array(
	'title'=>'Portfolio Video ',
	'page'=>'portfolio',
	'context'=>'normal',
	'priority'=>'high',
	'args'=>array(
		array(
			'id'=>'_bandit_portfolio_video_url',
			'label'=>'Video URL (Recommended)',
			'type'=>'text',
			'class'=>'large-text'
		),
		array(
			'id'=>'_bandit_portfolio_video_embed_code',
			'label'=>'Video Embed Code',
			'type'=>'textarea',
			'rows'=>'6'
		),
	)
);

/* ---- Post Formats ------------------------------------------------------- */

//! Audio Meta
if(FeatherCore::get_option('post_format_audio')) {
	$meta['bandit_format_audio']=array(
		'title'=>'Audio',
		'page'=>'post',
		'context'=>'normal',
		'priority'=>'high',
		'args'=>array(
			array(
				'id'=>'_bandit_audio_mp3_url',
				'label'=>'Audio URL (MP3)',
				'type'=>'text',
				'class'=>'large-text'
			),
			array(
				'id'=>'_bandit_audio_ogg_url',
				'label'=>'Audio URL (OGG)',
				'type'=>'text',
				'class'=>'large-text'
			)
		)
	);
}

//! Link Meta
if(FeatherCore::get_option('post_format_link')) {
	$meta['bandit_format_link']=array(
		'title'=>'Link',
		'page'=>'post',
		'context'=>'normal',
		'priority'=>'high',
		'args'=>array(
			array(
				'id'=>'_bandit_link_title',
				'label'=>'Link Title',
				'type'=>'text',
				'class'=>'large-text'
			),
			array(
				'id'=>'_bandit_link_url',
				'label'=>'Link URL',
				'type'=>'text',
				'class'=>'large-text'
			)
		)
	);
}

//! Quote Meta
if(FeatherCore::get_option('post_format_quote')) {
	$meta['bandit_format_quote']=array(
		'title'=>'Quote',
		'page'=>'post',
		'context'=>'normal',
		'priority'=>'high',
		'args'=>array(
			array(
				'id'=>'_bandit_quote',
				'label'=>'Quote',
				'type'=>'textarea',
				'rows'=>'4'
			),
			array(
				'id'=>'_bandit_quote_author',
				'label'=>'Quote Author',
				'type'=>'text',
				'class'=>'large-text'
			)
		)
	);
}

//! Video Meta
if(FeatherCore::get_option('post_format_video')) {
	$meta['bandit_format_video']=array(
		'title'=>'Video',
		'page'=>'post',
		'context'=>'normal',
		'priority'=>'high',
		'args'=>array(
			array(
				'id'=>'_bandit_video_url',
				'label'=>'Video URL (Recommended)',
				'type'=>'text',
				'class'=>'large-text'
			),
			array(
				'id'=>'_bandit_video_embed_code',
				'label'=>'Video Embed Code',
				'type'=>'textarea',
				'rows'=>'6'
			),
		)
	);
}
