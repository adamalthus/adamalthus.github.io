<?php

/*---------------------------------------------------------------------------*
 * Peak Theme Settings
 *---------------------------------------------------------------------------*/


/*---------------------------------------------------------------------------*
 * Peak Tab
 *---------------------------------------------------------------------------*/

/* ---- Theme Styles ------------------------------------------------------- */

if(FeatherTheme::styles()) {
	$setting['themestyles']=array(
		'title'=>'Styles',
		'desc'=>'Select a theme style below.',
		'tab'=>'theme',
		'fields'=>array(
			'theme_style'=>array(
				'label'=>'Theme Style',
				'type'=>'select',
				'choices'=>FeatherTheme::styles()
			)
		)
	);
}

/* ---- Portfolio ---------------------------------------------------------- */

$setting['portfolio']=array(
	'title'=>'Portfolio',
	'desc'=>'Enable the portfolio, set navigation type, and rewrite URL\'s.',
	'tab'=>'theme',
	'fields'=>array(
		// Enable portfolio
		'theme_portfolio'=>array(
			'label'=>'Enable Portfolio',
			'type'=>'checkbox',
			'choices'=>array(
				'theme_portfolio'=>'Enable portfolio custom post type'
			)
		),
		// Portfolio AJAX navigation
		'theme_portfolio_ajaxnav'=>array(
			'label'=>'AJAX Navigation',
			'type'=>'checkbox',
			'choices'=>array(
				'theme_portfolio_ajaxnav'=>'Load additional items via AJAX <small><strong>'.
					'[ standard nav shows in IE &lt; 9 ]</strong></small>'
			)
		),
		// Portfolio Rewrite Type
		'theme_portfolio_rewrite_type'=>array(
			'label'=>'Post Type Rewrite URL',
			'type'=>'text',
			'class'=>'medium-text'
		),
		// Portfolio Rewrite Category
		'theme_portfolio_rewrite_category'=>array(
			'label'=>'Category Rewrite URL',
			'type'=>'text',
			'class'=>'medium-text'
		)
	)
);

// Portfolio Category Templates
if(FeatherCore::get_theme_option('theme_portfolio')) {

	// Get portfolio categories
	$port_cats=get_categories(array('taxonomy'=>'portfolio_category',
		'orderby'=>'name','hide_empty'=>0));

	// Set portfolio category template fields
	$port_cat_fields=array();
	$port_cat_templates=array();

	// Templates
	for($i=1;$i<=12;$i++) 
		$port_cat_templates[$i]='Template '.$i;

	// Fields
	foreach($port_cats as $cat) {
		$port_cat_fields['theme_portfolio_'.$cat->slug]=array(
			'label'=>$cat->name,
			'type'=>'select',
			'callback'=>'FeatherTheme::print_field_portcat_templates',
			'choices'=>$port_cat_templates
		);
	}

	// Category Templates, # of Items, and Lightbox
	$setting['portfolio_cat_templates']=array(
		'title'=>'Portfolio Category Templates',
		'desc'=>'Select a template for each category below and the number of items to display per category',
		'tab'=>'theme',
		'fields'=>$port_cat_fields
	);

	// Category Template Guide
	$setting['portfolio_template_guide']=array(
		'title'=>'Portfolio Template Guide',
		'desc'=>'',
		'tab'=>'theme',
		'fields'=>array(
			'theme_portfolio_templates'=>array(
				'label'=>'',
				'callback'=>'FeatherTheme::print_field_port_template_guide',
			)
		)
	);
}


/*---------------------------------------------------------------------------*
 * General Tab
 *---------------------------------------------------------------------------*/

/* ---- Custom Logo and Tagline -------------------------------------------- */

$setting['customlogo']=array(
	'title'=>'Custom Logo & Tagline',
	'desc'=>'Use a custom logo by uploading an image or selecting an existing '.
		'image from the Media Library.',
	'tab'=>'general',
	'fields'=>array(
		'custom_logo'=>array(
			'label'=>'Logo URL',
			'type'=>'image'
		),
		'disable_tagline'=>array(
			'label'=>'Tagline',
			'type'=>'checkbox',
			'choices'=>array(
				'disable_tagline'=>'Disable tagline'
			)
		)
	)
);

/* ---- RSS Feed ----------------------------------------------------------- */

$setting['rssfeed']=array(
	'title'=>'RSS Feed',
	'desc'=>'If you use a service such as FeedBurner or'.
		' FeedBlitz enter the full URL of your feed below.',
	'tab'=>'general',
	'fields'=>array(
		// Feed URL
		'feed_url'=>array(
			'label'=>'Feed URL',
			'type'=>'text',
			'class'=>'regular-text',
		)
	)
);

/* ---- Comments ----------------------------------------------------------- */

$setting['comments']=array(
	'title'=>'Comments',
	'desc'=>'Disable comments from displaying on all posts, '.
		'all pages, or both.',
	'tab'=>'general',
	'fields'=>array(
		// Disable Comments
		'disable_comments'=>array(
			'label'=>'Disable Comments',
			'type'=>'checkbox',
			'choices'=>array(
				'comments_pages'=>'Disable comments on pages',
				'comments_posts'=>'Disable comments on posts'
			)
		)
	)
);

/* ---- Custom Styles & Functions ------------------------------------------ */

$setting['customcss']=array(
	'title'=>'Custom Styles',
	'desc'=>'Use style-custom.css to override theme styles or create new ones.',
	'tab'=>'general',
	'fields'=>array(
		// Enable Customization
		'customcss'=>array(
			'label'=>'Enable Customization',
			'type'=>'checkbox',
			'choices'=>array(
				'custom_styles'=>'Enable custom styles [ <strong>style-custom.css</strong> ]',
			)
		)
	)
);

/* ---- General ------------------------------------------------------------ */

$setting['social']=array(
	'title'=>'Social Media',
	'desc'=>'Display links to your social media profiles by entering your '.
		'information for each site. If left blank no link will be displayed.',
	'tab'=>'general',
	'fields'=>array(
		// Facebook
		'social_facebook'=>array(
			'label'=>'Facebook (Profile ID)',
			'type'=>'text',
			'class'=>'medium-text',
		),
		// Flickr
		'social_flickr'=>array(
			'label'=>'Flickr (Flickr ID)',
			'type'=>'text',
			'class'=>'medium-text'
		),
		// Twitter
		'social_twitter'=>array(
			'label'=>'Twitter (Username)',
			'type'=>'text',
			'class'=>'medium-text'
		),
	)
);

/* ---- Analytics ---------------------------------------------------------- */

$setting['analytics']=array(
	'title'=>'Analytics Script',
	'desc'=>'If you use a service such as Google Analytics paste your tracking '.
		'code below.',
	'tab'=>'general',
	'fields'=>array(
		'analytics_location'=>array(
			'label'=>'Script Location',
			'type'=>'radio',
			'choices'=>array(
				'header'=>'Header',
				'footer'=>'Footer'
			)
		),
		'analytics_script'=>array(
			'label'=>'Analytics Script',
			'type'=>'textarea',
			'rows'=>'4'
		)
	)
);
