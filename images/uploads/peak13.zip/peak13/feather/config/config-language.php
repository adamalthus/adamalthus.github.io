<?php

/*---------------------------------------------------------------------------*
 * Peak Language Configuration
 *---------------------------------------------------------------------------*/

/* ----  Posts ------------------------------------------------------------- */

$lang['lang_posts']=array(
	'title'=>'Posts',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Read more
		'post_read_more'=>array(
			'label'=>'Read more',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Continue Reading',
		),
		// Page Links
		'post_page_links'=>array(
			'label'=>"Page Links",
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Pages:'
		),
		// Navigation Links
		'post_nav_prev'=>array(
			'label'=>'Navigation Link - Previous',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'&larr; Previous'
		),
		'post_nav_next'=>array(
			'label'=>'Navigation Link - Next',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Next &rarr;'
		),
		'post_meta_ago'=>array(
			'label'=>'Meta - Ago',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'ago'
		),
		'post_meta_by'=>array(
			'label'=>'Meta - By',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'by'
		),
		'post_meta_in'=>array(
			'label'=>'Meta - In',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'in'
		)
	)
);

/* ---- Comments ----------------------------------------------------------- */

$lang['lang_comments']=array(
	'title'=>'Comments',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Title
		'comments_title'=>array(
			'label'=>'Title',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Discussion'
		),
		// Navigation Links
		'comments_nav_prev'=>array(
			'label'=>'Navigation Link - Prev',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'&larr; Previous'
		),
		'comments_nav_next'=>array(
			'label'=>'Navigation Link - Next',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Next &rarr;'
		),
		// Form Title - Add
		'comments_form_title_add'=>array(
			'label'=>'Form Title - Add Comment',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Add a Comment'
		),
		// Form Title - Add
		'comments_form_title_reply'=>array(
			'label'=>'Form Title - Reply',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Reply to %s'
		),
		// Form Title - Add
		'comments_form_cancel_reply'=>array(
			'label'=>'Cancel Reply',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Cancel reply'
		),
		// Form - Name
		'comments_form_name'=>array(
			'label'=>'Form - Name',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Name'
		),
		// Form - Email
		'comments_form_email'=>array(
			'label'=>'Form - Email',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Email'
		),
		// Form - Name
		'comments_form_website'=>array(
			'label'=>'Form - Website',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Website'
		),
		// Form - Name
		'comments_form_comment'=>array(
			'label'=>'Form - Comment',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Comment'
		)
	)
);

/* ---- Archive ------------------------------------------------------------ */

$lang['lang_archive']=array(
	'title'=>'Archive Headings',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Author
		'archive_heading_author'=>array(
			'label'=>'Author',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Author :'
		),
		// Category
		'archive_heading_category'=>array(
			'label'=>'Category',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Category :'
		),
		// Day
		'archive_heading_day'=>array(
			'label'=>'Day',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Daily :'
		),
		// Month
		'archive_heading_month'=>array(
			'label'=>'Month',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Monthly :'
		),
		// Tag
		'archive_heading_tag'=>array(
			'label'=>'Tag',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Tagged :'
		),
		// Year
		'archive_heading_year'=>array(
			'label'=>'Year',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Yearly :'
		),
	)
);

/* ---- Search ------------------------------------------------------------- */

$lang['lang_search']=array(
	'title'=>'Search Results',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Search Results Heading
		'search_heading'=>array(
			'label'=>'Search Heading',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Search Results'
		),
		// Search Text
		'search_text'=>array(
			'label'=>'Search Text',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'You searched for <strong>%s</strong> and we found the following...'
		),
		// No Results - Title
		'search_noresults_title'=>array(
			'label'=>'No Results - Title',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Absolutely nothing'
		),
		// No Results - Title
		'search_noresults_text'=>array(
			'label'=>'No Results - Text',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'The good news is you can try again.'
		),
	)
);


/* ---- 404 Page ----------------------------------------------------------- */

$lang['lang_404']=array(
	'title'=>'404 Page',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// 404 Heading
		'404_heading'=>array(
			'label'=>'404 Heading',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Error 404'
		),
		// 404 Text
		'404_text'=>array(
			'label'=>'404 Text',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'The page you are looking for could not be found.'
		),
	)
);

/* ---- Footer ------------------------------------------------------------- */

$lang['lang_footer']=array(
	'title'=>'Footer',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Back To Top
		'footer_back_to_top'=>array(
			'label'=>'Back To Top',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Back To Top'
		)
	)
);

/* ---- Portfolio ---------------------------------------------------------- */

$lang['lang_portfolio']=array(
	'title'=>'Portfolio',
	'desc'=>'',
	'tab'=>'language',
	'fields'=>array(
		// Portfolio Heading
		'portfolio_heading'=>array(
			'label'=>'Heading',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'Please select a category above.'
		),
		// Portfolio Description
		'portfolio_desc'=>array(
			'label'=>'Descripton',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'View some of my latest work.'
		),
		// Go Back Button
		'portfolio_button_goback'=>array(
			'label'=>'Back Button',
			'type'=>'text',
			'class'=>'regular-text',
			'std'=>'&larr; Go Back'
		)
	)
);
