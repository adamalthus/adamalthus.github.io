<?php

/*---------------------------------------------------------------------------*
 * Peak Post Type Configuration
 *---------------------------------------------------------------------------*/

/* ---- Portfolio Post Type ------------------------------------------------ */

// Portfolio Post Type
if(FeatherCore::get_theme_option('theme_portfolio')) {

	// Get URL option
	$rewrite_type_url=FeatherCore::get_theme_option('theme_portfolio_rewrite_type');

	// Portfolio Rewrite URL
	if($rewrite_type_url)
		$rewrite=array('slug'=>$rewrite_type_url,'with_front'=>FALSE);
	else
		$rewrite=FALSE;

	// Post Type
	$type['portfolio']=array(
		'labels'=>array(
			'name'=>__('Portfolio'),
			'add_new_item'=>__('Add New Item'),
			'edit_item'=>__('Edit Item'),
			'view_item'=>__('View Item'),
			'search_items'=>__('Search Items'),
			'not_found'=>__('No Items Found')
		),
		'public'=>TRUE,
		'has_archive'=>TRUE,
		'supports'=>array('title','editor','excerpt','author','thumbnail'),
		'rewrite'=>$rewrite,
		'menu_position'=>5,
		'taxonomies'=>array('portfolio_category')
	);

}