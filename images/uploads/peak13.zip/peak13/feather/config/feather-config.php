<?php

/*---------------------------------------------------------------------------*
 * Feather Configuration
 *---------------------------------------------------------------------------*/

/* ---- Menus -------------------------------------------------------------- */

//! Menus
$config['MENUS']=array(
	'bandit_nav_header'=>'Header Navigation',
	'bandit_nav_footer'=>'Footer Navigation'
);


/* ---- Sidebars & Widgets ------------------------------------------------- */

//! Sidebars
$config['SIDEBARS']=array(
	array(
		'id'						=> 'bandit_sidebar',
		'name'					=> 'Sidebar',
		'before_widget'	=> '<li id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</li>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'		=> '</h3>',
	)
);

//! Widgets
$config['WIDGETS']=array(
	'bandit-flickr'=>'Bandit_Flickr',
	'bandit-recentcomments'=>'Bandit_RecentComments',
	'bandit-tabs'=>'Bandit_Tabs'
);


/* ---- Images ------------------------------------------------------------- */

//! Image Sizes
$config['IMAGE_SIZES']=array(
	'post-format-620'=>array('width'=>620,'height'=>'0')
);


/* ---- Custom Meta, Taxonomy, & Post Types -------------------------------- */

//! Custom Meta
$config['CUSTOM_META']=TRUE;

//! Custom Taxonomy
$config['CUSTOM_TAXONOMY']=TRUE;

//! Custom Post Type
$config['CUSTOM_TYPE']=TRUE;


/* ---- Modules ------------------------------------------------------------ */

//! Modules
$config['MODULES']=array(
	'bandit-liked'=>'BanditLiked'
);


/* ---- Admin Settings ----------------------------------------------------- */

//! Theme Option Name
$config['OPTION_NAME']='bandit_theme';

//! Admin Tabs
$config['OPTION_TABS']=array(
	'theme'=>'Peak',
	'general'=>'General',
	'language'=>'Language'
);

//! Required Framework Options
$config['OPTION_REQUIRED']=array(
	'post_thumbnails'=>'1'
);
