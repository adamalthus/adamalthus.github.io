<?php

/*---------------------------------------------------------------------------*
 * Peak Taxonomy Configuration
 *---------------------------------------------------------------------------*/

/* ---- Portfolio Category ------------------------------------------------- */

//! Portfolio Category Taxonomy
if(FeatherCore::get_theme_option('theme_portfolio')) {

	// Get URL options
	$rewrite_type_url=FeatherCore::get_theme_option('theme_portfolio_rewrite_type');
	$rewrite_cat_url=FeatherCore::get_theme_option('theme_portfolio_rewrite_category');

	// Portfolio Category Rewrite URL
	if($rewrite_type_url && $rewrite_cat_url) {
		$slug=$rewrite_type_url.'/'.$rewrite_cat_url;
		$rewrite=array('slug'=>$slug,'with_front'=>FALSE);
	} else {
		$rewrite=FALSE;
	}

	//! Taxonomy
	$tax['portfolio_category']=array(
		'type'=>'portfolio',
		'args'=>array(
			'hierarchical'=>TRUE,
			'rewrite'=>$rewrite
		)
	);

}
