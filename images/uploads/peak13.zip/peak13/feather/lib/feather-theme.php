<?php

/**
	Peak Theme Library

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package Theme
		@version 1.3
**/

//! Theme specific methods
class FeatherTheme extends FeatherBase {

	//@{ Theme details
	const
		THEME_Name='Peak',
		THEME_Version='1.3';
	//@}

	protected static
		//! Theme Language
		$theme_lang;

	/**
		Initialize Theme
			@public
	**/
	static function init() {
		// Content width
		global $content_width;
		if(!isset($content_width))
			$content_width=960;
		// Get theme language options
		self::$theme_lang=get_option('bandit_language');
		// Theme activation
		if('themes.php'==self::$vars['PAGENOW'] && isset($_GET['activated']))
			self::activation();

		// Theme admin
		if(is_admin()) {
			// Upgrade check
			self::upgrade_check();
			// Peak settings menu
			if(isset(self::$config['OPTION_TABS']))
				add_action('admin_menu',__CLASS__.'::admin_menu');
			// Admin init
			$pages=array('themes.php','options.php');
			if(in_array(self::$vars['PAGENOW'],$pages))
				add_action('admin_init',__CLASS__.'::admin_init');
			// Post formats javascript
			if(self::get_option('post_formats')) {
				add_action('admin_print_scripts-post-new.php',__CLASS__.'::admin_postformats_javascript');
				add_action('admin_print_scripts-post.php',__CLASS__.'::admin_postformats_javascript');
			}
			// Delete attachment action
			if(current_user_can('delete_posts'))
				add_action('delete_attachment',__CLASS__.'::admin_delete_dynamic_images',10);
		}

		// Theme non-admin
		if(!is_admin()) {
			// Load Helper
			self::load_theme_file('bandit-helper','lib');
			// Shortcodes
			if(self::load_theme_file('bandit-shortcode','lib')) {
				$shortcodes=array_diff(get_class_methods('BanditShortcode'),
					get_class_methods('FeatherBase'));
				foreach($shortcodes as $shortcode)
					add_shortcode($shortcode,'BanditShortcode::'.$shortcode);
			}
			// Theme filters
			add_action('after_setup_theme',__CLASS__.'::filters');
			// Theme javascript
			add_action('template_redirect',__CLASS__.'::javascript');
			// Add action to output to head
			add_action('wp_head',__CLASS__.'::wp_head');
			// Add action to output to footer
			add_action('wp_footer',__CLASS__.'::wp_footer');
		}
	}

	/**
		Theme Activation
			@private
	**/
	private static function activation() {
		// Set default language options
		if(!self::$theme_lang) {
			self::$theme_lang=array();
			// Load language
			$lang=FeatherConfig::theme('config-language','lang');
			// Loop through language settings
			foreach($lang as $key=>$value) {
				foreach($value['fields'] as $option=>$args)
					self::$theme_lang[$option]=$args['std'];
			}
			// Save language settings
			update_option('bandit_language',self::$theme_lang);
		}
		// Create images DB
		self::create_images_db();
		// Set large image size
		update_option('large_size_w',940);
		update_option('large_size_h',0);
	}

	/**
		Create DB
			@public
	**/
	static function create_images_db() {
		global $wpdb;
		$table_name='bandit_images';
		// Create dynamic images table if it doesn't exist
		if(!$wpdb->get_var("show tables like '".$table_name."'")) {
			$sql = "CREATE TABLE  ".$table_name." (
							image_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
							post_id bigint(20) unsigned NOT NULL,
							image_file varchar(255) DEFAULT '' NOT NULL,
							UNIQUE KEY image_id (image_id)
							) CHARSET=utf8;";
			require_once(ABSPATH.'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
	}

	/**
		Upgrade check
			@private
	**/
	private static function upgrade_check() {
		// Theme Version
		$version=self::get_theme_option('theme_version');
		// If version not set, possibly older version of framework
		if(!$version) {
			self::$option=get_option('bandit_framework');
			$version=self::get_option('theme_version');
		}
		// Upgrade if necessary
		if($version && ($version < self::THEME_Version)) {
			self::load_theme_file('bandit-upgrade','lib');
				BanditUpgrade::init($version);
		} elseif(!$version) {
			// Set theme framework options
			self::$option['auto_feed_links']='1';
			self::$option['post_thumbnails']='1';
			update_option('feather',self::$option);
			
			// Set default theme options
			self::$theme_option=array(
				'theme_version'=>FeatherTheme::THEME_Version,
				'comments_pages'=>'1'
			);
			update_option('bandit_theme',self::$theme_option);
		}
	}

	/**
		Get lang option
			@param $option string
			@public
	**/
	static function get_theme_lang($option=NULL) {
		if(isset(self::$theme_lang[$option]))
			$result=self::$theme_lang[$option];
		else
			$result=FALSE;
		return $result;
	}

	/**
		Javascript
			@public
	**/
	static function javascript() {
		// Default scripts
		$scripts=array('jquery','jquery-ui-core','jquery-ui-tabs','slides');
		// Register slides
		wp_register_script('slides',get_bloginfo('template_url').'/js/jquery.slides.min.js',FALSE,'2.0.0');
		// Register jplayer
		wp_register_script('jplayer',get_bloginfo('template_url').'/js/jquery.jplayer.min.js',FALSE,'1.1.8');
		// Register prettyPhoto
		wp_register_script('prettyPhoto',get_bloginfo('template_url').'/js/jquery.prettyPhoto.js',FALSE,'3.1.3');

		// Enqueue jplayer
		if((is_home() || is_single() || is_archive()) && 'portfolio'!=get_post_type())
			$scripts[]='jplayer';

		// Enqueue prettyPhoto
		if('portfolio'==get_post_type() && is_tax('portfolio_category')) {
			// Get portfolio category
			$term=get_term_by('slug',get_query_var( 'term' ),get_query_var('taxonomy'));
			// Check if lightbox enabled
			if(self::get_theme_option('theme_portfolio_'.$term->slug.'_lightbox')) {
				wp_enqueue_style('prettyPhoto',get_bloginfo('template_url').
					'/css/prettyPhoto/prettyPhoto.css',FALSE,'3.1.3');
				$scripts[]='prettyPhoto';
			}
		}

		// Load theme script
		wp_enqueue_script('bandit-theme',get_bloginfo('template_url').'/js/jquery.theme.js',$scripts,'1.3');
		// AJAX url variable
		wp_localize_script('bandit-theme','bandit',array('ajaxurl'=>admin_url('admin-ajax.php')));
	}

	/**
		Theme filters
			@public
	**/
	static function filters() {
		if(self::get_config('FILTERS'))
			foreach(self::$config['FILTERS'] as $tag=>$function) {
				if(!isset($function['priority']))
					$function['priority']=10;
				if(!isset($function['args']))
				 $function['args']=1;
				add_filter($tag,__CLASS__.'::'.$function['name'],
					$function['priority'],$function['args']);
			}
		// Feed link filter
		if(self::get_theme_option('feed_url'))
			add_filter('feed_link',__CLASS__.'::filter_feedlink',10,2);
	}

	/**
		Theme styles
			@public
	**/
	static function styles() {
		// Styles directory
		$styles_dir=TEMPLATEPATH.'/styles';
		// Default style
		$default=array('0'=>'Default');
		// Empty array
		$styles=array();
		if(is_dir($styles_dir) && $handle=opendir($styles_dir)) {
			while(false !== ($file=readdir($handle))) {
				if($file!="." && $file!=".." && is_file($styles_dir.'/'.$file)) {
					$tmp = new \SplFileObject($styles_dir.'/'.$file);
					$tmp->seek(1);
					$name=substr(esc_html($tmp->current()),7);
					$styles[$file]=$name;
				}
			}
			closedir($handle);
			// Combine arrays
			if($styles) {
				asort($styles);
				$styles=$default+$styles;
			}
		}
		return $styles?$styles:FALSE;
	}

	/**
		Theme WP Head
			@public
	**/
	static function wp_head() {
		// Analytics script
		if(self::get_theme_option('analytics_script'))
			if('header'===self::get_theme_option('analytics_location'))
				echo self::$theme_option['analytics_script']."\n";
	}

	/**
		Theme WP Footer
			@public
	**/
	static function wp_footer() {
		// Analytics script
		if(self::get_theme_option('analytics_script'))
			if('footer'===self::get_theme_option('analytics_location'))
				echo self::$theme_option['analytics_script']."\n";
	}

	/**
		Theme feed link filter
			@public
	**/
	static function filter_feedlink($output,$feed) {
		$feed_url=self::get_theme_option('feed_url');
		$feed_array = array('rss'=>$feed_url, 'rss2'=>$feed_url,
			'atom'=>$feed_url, 'rdf'=>$feed_url, 'comments_rss2'=>'');
		$feed_array[$feed]=$feed_url;
		return $feed_array[$feed];
	}

	/**
		Peak admin menu
			@public
	**/
	static function admin_menu() {
		// Add page to the Appearance menu
		add_theme_page('Theme Options','Theme Options','edit_theme_options',
			'feather',__CLASS__.'::admin_options_page');
	}

	/**
		Peak options page
			@public
	**/
	static function admin_options_page() {
		$file='theme-options-page';
		if(!self::load_theme_file($file,'tmpl')) {
			$message=sprintf(self::TEXT_File,$file.'.php');
			echo '<div class="wrap"><div id="message" class="error"><p>'.
				'Feather : '.$message.'</p></div></div>';
		}
	}

	/**
		Theme admin init
			@public
	**/
	static function admin_init() {
		// Theme options stylesheet
		add_action('admin_print_styles-appearance_page_feather',
			__CLASS__.'::admin_stylesheets');
		// Theme options javacript
		add_action('admin_print_scripts-appearance_page_feather',
			__CLASS__.'::admin_javascript');
		// Register theme settings
		register_setting('bandit_theme-settings','bandit_theme',
			__CLASS__.'::admin_validate_settings');
		// Register language settings
		register_setting('bandit_language-settings','bandit_language',
			__CLASS__.'::admin_validate_settings');
		// Initialize theme settings
		self::admin_settings_init();
	}

	/**
		Theme settings init
			@private
	**/
	private static function admin_settings_init() {
		$tab=FeatherAdmin::get_current_options_page_tab('theme');
		// Theme Settings (non-language)
		if('language'!==$tab) {
			// Theme settings
			self::$theme_setting=FeatherConfig::theme('config-settings','setting');
			// Process settings
			FeatherAdmin::process_settings(self::$theme_setting,'bandit_theme');
		}
		// Language Settings
		if('language'==$tab) {
			// Language settings
			self::$theme_setting=FeatherConfig::theme('config-language','lang');
			// Process settings
			FeatherAdmin::process_settings(self::$theme_setting,'bandit_language',
				__CLASS__.'::get_theme_lang');
		}
	}

	/**
		Theme admin stylesheets
			@public
	**/
	static function admin_stylesheets() {
		// Framework stylesheet
		wp_enqueue_style('feather-admin-css',
			FEATHER_URL.'assets/css/feather-admin.css',FALSE,20110921);
		// Peak stylesheet
		wp_enqueue_style('theme-admin-css',
			FEATHER_URL_THEME.'assets/css/theme-admin.css',FALSE,20110921);
		// Load tab specific styles
		if('general'==FeatherAdmin::get_current_options_page_tab('theme'))
			wp_enqueue_style('thickbox');
	}

	/**
		Theme javascripts
			@public
	**/
	static function admin_javascript() {
		// Register scripts
		wp_register_script('theme-admin-general',FEATHER_URL_THEME.'assets/js/theme-admin-general.js',
			array('media-upload','thickbox','jquery'),20110921);
		// Load tab specific scripts
		if('general'==FeatherAdmin::get_current_options_page_tab('theme'))
			wp_enqueue_script('theme-admin-general');
	}

	/**
		Post formats javascript
			@public
	**/
	static function admin_postformats_javascript() {
		wp_enqueue_script('theme-admin-postformats',FEATHER_URL_THEME.
			'assets/js/theme-admin-postformats.js',array('jquery'),20110921);
	}

	/**
		Delete dynamic images
			@public
	**/
	static function admin_delete_dynamic_images($post_id) {
		// Get upload dir and path
		$upload_dir=wp_upload_dir();
		$upload_path=$upload_dir['basedir'];
		global $wpdb;
		$results=$wpdb->get_results("SELECT * FROM bandit_images WHERE post_id = '$post_id' ", ARRAY_A);
		if($results) {
			$images=array();
			// Set full image paths
			foreach($results as $result)
				$images[]=$upload_path.$result['image_file'];
			// Delete images
			foreach($images as $image)
				@unlink($image);
			// Delete DB entries
			$wpdb->query("DELETE FROM bandit_images WHERE post_id = '$post_id' ");
		}
	}

	/**
		Theme validate admin settings
			@public
	**/
	static function admin_validate_settings($input) {
		// Get tab
		$tab=$input['tab'];
		// Unset bandit_tab option
		unset($input['tab']);

		// Theme Tab
		if('theme'==$tab) {
			// Get current options
			$valid=self::$theme_option;
			// Define checkbox options
			$checkboxes='theme_portfolio|theme_portfolio_ajaxnav';
			// Validate options
			$valid['theme_style']=wp_filter_nohtml_kses($input['theme_style']);
			foreach(explode('|',$checkboxes) as $option) 
				$valid[$option]=isset($input[$option])?'1':'0';
			// Rewrite URL's
			$valid['theme_portfolio_rewrite_type']=wp_filter_nohtml_kses($input['theme_portfolio_rewrite_type']);
			$valid['theme_portfolio_rewrite_category']=wp_filter_nohtml_kses($input['theme_portfolio_rewrite_category']);
			// Portfolio Categories
			if($valid['theme_portfolio']) {
				// Get portfolio categories
				$port_cats=get_categories(array('taxonomy'=>'portfolio_category','orderby'=>'name','hide_empty'=>0));
				foreach($port_cats as $category) {
					if(isset($category->slug)) {
						$option_name='theme_portfolio_'.$category->slug;
						$valid[$option_name]=in_array($input[$option_name],range(1,12))?$input[$option_name]:'1';
						$valid[$option_name.'_num']=in_array($input[$option_name.'_num'],range(1,40))?$input[$option_name.'_num']:'0';
						$valid[$option_name.'_lightbox']=isset($input[$option_name.'_lightbox'])?'1':'0';
					}
				}
				// Flush rewrite rules
				flush_rewrite_rules();
			}
		}

		// General Tab
		if('general'==$tab) {
			// Get current options
			$valid=self::$theme_option;
			// Define checkbox options
			$checkboxes='disable_tagline|custom_styles|'.
				'comments_pages|comments_posts|analytics_location';
			// Validate options
			foreach(explode('|',$checkboxes) as $option) 
				$valid[$option]=isset($input[$option])?'1':'0';
			$valid['custom_logo']=wp_filter_nohtml_kses($input['custom_logo']);
			$valid['feed_url']=wp_filter_nohtml_kses($input['feed_url']);
			$valid['social_facebook']=wp_filter_nohtml_kses($input['social_facebook']);
			$valid['social_flickr']=wp_filter_nohtml_kses($input['social_flickr']);
			$valid['social_twitter']=wp_filter_nohtml_kses($input['social_twitter']);
			$valid['analytics_location']=('header'===$input['analytics_location']?'header':'footer');
			$valid['analytics_script']=$input['analytics_script'];
		}

		// Language Tab
		if('language'==$tab) {
			// Save language settings
			if(!isset($input['reset'])) {
				// Get current settings
				$valid=self::$theme_lang;
				// Language settings
				self::$theme_setting=FeatherConfig::theme('config-language','lang');
				// Loop through language settings
				foreach(self::$theme_setting as $key=>$value) {
					// Loop through fields
					foreach($value['fields'] as $option=>$args)
						$valid[$option]=wp_filter_kses($input[$option]);
				}
			}
			// Reset language settings
			if(isset($input['reset'])) {
				// Unset reset option
				unset($input['reset']);
				// Set blank option
				update_option('bandit_language',array());
				// Language settings
				self::$theme_setting=FeatherConfig::theme('config-language','lang');
				// Loop through language settings
				foreach(self::$theme_setting as $key=>$value) {
					// Reset fields to defaults
					foreach($value['fields'] as $option=>$args)
						$valid[$option]=$args['std'];
				}
			}
		}
		// Settings saved notice
		add_settings_error('feather_setting_notices',
			esc_attr('settings_updated'),__('Settings saved.'),'updated');
		// Return validated options
		return $valid;
	}

	/**
		Portfolio category fields
			@public
	**/
	static function print_field_portcat_templates($args) {
		// Template fields
		$output='<select name="bandit_theme['.$args['id'].']">';
		foreach($args['choices'] as $id=>$label)
			$output.='<option value="'.$id.'" '.selected($id,self::get_theme_option($args['id']),FALSE).'>'.$label.'</option>';
		$output.='</select>';

		// Category items per page
		$output.='&nbsp;&nbsp; <select name="bandit_theme['.$args['id'].'_num]">';
		$output.='<option value="0" '.selected('0',self::get_theme_option($args['id'].'_num'),FALSE).'>All</option>';
		for($i=1;$i<=40;$i++)
			$output.='<option value="'.$i.'" '.selected($i,self::get_theme_option($args['id'].'_num'),FALSE).'>'.$i.'</option>';
		$output.='</select> Per Page';

		// Lightbox
		$output.='<div style="margin-top:10px;">';
		$output.='<input type="checkbox" name="bandit_theme['.$args['id'].'_lightbox]" value="1" '.
			checked(self::get_theme_option($args['id'].'_lightbox'), 1, FALSE).' /> Enable Lightbox</div>';
		$output.='<hr style="border-top:1px dotted #cfcfcf;border-bottom:1px dotted #fff;border-left:none;margin-left:-220px">';
		echo $output;
	}

	/**
		Portfolio template guide
			@public
	**/
	static function print_field_port_template_guide($args) {
		$url=FEATHER_URL_THEME.'assets/img';
?>
		<ul class="bandit_port_tmpl_guide">
			<li><img src="<?php echo $url; ?>/1-940x480.png"><br><strong>1</strong> - 940x480px</li>
			<li><img src="<?php echo $url; ?>/2-460x460.png"><br><strong>2</strong> - 460x460px</li>
			<li><img src="<?php echo $url; ?>/3-300x320.png"><br><strong>3</strong> - 300x320px</li>
			<li><img src="<?php echo $url; ?>/4-220x220.png"><br><strong>4</strong> - 220x220px</li>
			<li><img src="<?php echo $url; ?>/5-172x172.png"><br><strong>5</strong> - 172x172px</li>
			<li class="last"><img src="<?php echo $url; ?>/6-940x320.png"><br><strong>6</strong> - 940x320px</li>
			<li><img src="<?php echo $url; ?>/7-460x240.png"><br><strong>7</strong> - 460x240px</li>
			<li><img src="<?php echo $url; ?>/8-300x200.png"><br><strong>8</strong> - 300x200px</li>
			<li><img src="<?php echo $url; ?>/9-220x320.png"><br><strong>9</strong> - 220x320px</li>
			<li><img src="<?php echo $url; ?>/10-172x260.png"><br><strong>10</strong> - 172x260px</li>
			<li><img src="<?php echo $url; ?>/11-780x320.png"><br><strong>11</strong> - 780x320px</li>
			<li class="last"><img src="<?php echo $url; ?>/12-140x140.png"><br><strong>12</strong> - 140x140px</li>
		</ul>
<?php
	}

	/**
		Create meta boxess
			@public
	**/
	static function front_slider_meta($post,$metabox) {
		$output='<table class="form-table">'."\n";
		$output.='<tr>'."\n";
		$output.='<th><label>Images</label></th>'."\n";
		$output.='<td>'."\n";
		$output.='<a href="'.admin_url().'media-upload.php?post_id='.$post->ID.
			'&type=image&TB_iframe=1" id="add_image" class="thickbox">Add / Edit / Delete</a>'."\n";
		$output.='</td>'."\n";
		$output.='</tr>'."\n";
		$output.='</table>'."\n";
		echo $output;
	}

}
