<?php

/**
	Peak Upgrade Library

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package ThemeUpgrade
		@version 1.3
**/

//! Peak library
class BanditUpgrade extends FeatherBase {

	/**
		Initialize Upgrade
			@public
	**/
	static function init($version) {
		switch($version) {
			// Upgrade Version 1.1
			case '1.1':
				self::upgrade_121();
				self::upgrade_13();
				break;
			// Upgrade Version 1.2.1
			case '1.2.1':
				self::upgrade_13();
				break;
			// Upgrade Version 1.2.2
			case '1.2.2':
				self::upgrade_13();
				break;
		}
	}

	/**
		Upgrade to 1.2.1
			@private
	**/
	private static function upgrade_121() {
		// Backup old settings
		update_option('peak_framework_backup_121',self::$option);
		// Create images DB
		FeatherTheme::create_images_db();
		// Update theme version
		self::$option['theme_version']=FeatherTheme::THEME_Version;
		// Set large image size
		update_option('large_size_w',940);
		update_option('large_size_h',0);
		// Move social media settings
		$facebook=self::get_option('theme_facebook');
		$twitter=self::get_option('theme_twitter');
		self::$option['social_facebook']=$facebook?$facebook:'';
		self::$option['social_twitter']=$twitter?$twitter:'';
		// Enable post formats
		self::$option['format_aside']='1';
		self::$option['format_audio']='1';
		self::$option['format_chat']='1';
		self::$option['format_gallery']='1';
		self::$option['format_image']='1';
		self::$option['format_link']='1';
		self::$option['format_status']='1';
		self::$option['format_video']='1';
		// Unset deprecated options
		$deprecated='content_home_thumbnails|content_archive_thumbnails|'.
		'layout_container|layout_site|layout_sidebars|layout_content_size|'.
		'layout_sidebar1_size|layout_sidebar2_size|theme_twitter|'.
		'theme_facebook|theme_flickr|content_home';
		foreach(explode('|',$deprecated) as $item)
			if(isset(self::$option[$item]))
				unset(self::$option[$item]);
		update_option('bandit_framework',self::$option);
		// Update language options
		self::$theme_lang['post_meta_ago']='ago';
		self::$theme_lang['post_meta_by']='by';
		self::$theme_lang['post_meta_in']='in';
		self::$theme_lang['comments_form_name']='Name';
		self::$theme_lang['comments_form_email']='Email';
		self::$theme_lang['comments_form_website']='Website';
		self::$theme_lang['comments_form_comment']='Comment';
		update_option('bandit_language',self::$theme_lang);
	}

	/**
		Upgrade to 1.3
			@private
	**/
	private static function upgrade_13() {
		// Backup old settings
		update_option('peak_framework_backup_13',self::$option);
		// Delete bandit_framework option
		delete_option('bandit_framework');

		// Set framework version
		self::$option['version']=self::TEXT_Version;

		// Set theme name and version
		self::$theme_option=array();
		self::$theme_option['theme']=FeatherTheme::THEME_Name;
		self::$theme_option['theme_version']=FeatherTheme::THEME_Version;

		// Unset old theme version option
		unset(self::$option['theme_version']);

		// Set new framework options
		self::$option['auto_feed_links']='1';
		self::$option['post_formats']='1';
		self::$option['post_thumbnails']='1';

		// Move theme options
		$theme_options='theme_style|custom_logo|disable_tagline|feed_url|'.
			'comments_pages|comments_posts|social_facebook|social_flickr|'.
			'social_twitter|analytics_location|analytics_script';
		foreach(explode('|',$theme_options) as $t_option) {
			if(isset(self::$option[$t_option])) {
				// Set new option
				self::$theme_option[$t_option]=self::$option[$t_option];
				// Unset old option
				unset(self::$option[$t_option]);
			}
		}

		// Set new post format options
		foreach(explode('|',self::$vars['WP_POST_FORMATS']) as $format) {
			if(isset(self::$option['format_'.$format])) {
				// Set new post format option
				self::$option['post_format_'.$format]=self::$option['format_'.$format];
				// Unset old post format option
				unset(self::$option['format_'.$format]);
			}
		}

		// Is portfolio enabled?
		if(self::get_option('theme_portfolio')) {
			// Move portfolio options
			foreach(self::$option as $p_id=>$p_option) {
				$pos=strpos($p_id,'theme_portfolio');
				if($pos!==FALSE) { 
					// Set new option
					self::$theme_option[$p_id]=self::$option[$p_id];
					// Unset old option
					unset(self::$option[$p_id]);
				}
			}
		}

		// Update options
		update_option('feather',self::$option);
		update_option('bandit_theme',self::$theme_option);

		// Store backup
		update_option('peak_framework_13',self::$option);
		update_option('peak_theme_13',self::$theme_option);
	}

}
