<?php

/**
	Shortcodes for the Bandit Framework

	The contents of this file are subject to the terms of the GNU General
	Public License Version 2.0. You may not use this file except in
	compliance with the license. Any of the license terms and conditions
	can be waived if you get permission from the copyright holder.

	Copyright (c) 2011 Bandit Media
	Jermaine Marée

		@package BanditShortcode
		@version 1.3
**/

//! Shortcodes
class BanditShortcode extends FeatherBase {

	protected static
		//! Global variables
		$vars;

	/**
		Box
			@param $atts array
			@param $content string
			@public
	**/
	static function box($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'type'=>'info',
		), $atts) );
		if(!in_array($type,array('info','download','note','warning')))
			$type='info';
		$output='<div class="box-'.$type.'">'.$content.'</div>';
		return $output;
	}

	/**
		Button
			@param $atts array
			@param $content string
			@public
	**/
	static function button($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'link'=>'#',
		), $atts) );
		$output='<p><a class="btn-a" href="'.strip_tags($link).'">'.strip_tags($content).'</a></p>';
		return $output;
	}

	/**
		Columns
			@param $atts array
			@param $content string
			@public
	**/
	static function column($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'size'=>'one-third',
			'last'=>FALSE
		), $atts) );
		$lastclass=$last?' last':'';
		$output='<div class="'.strip_tags($size).$lastclass.'">'.do_shortcode($content).'</div>';
		if($last)
			$output.='<div class="divider"></div>';
		return $output;
	}

	/**
		Divider Top
			@param $atts array
			@param $content string
			@public
	**/
	static function divider_top($atts,$content=NULL) {
		$output='<div class="sc-divider top"><a href="#">Top</a></div>';
		return $output;
	}

	/**
		Dropcap
			@param $atts array
			@param $content string
			@public
	**/
	static function dropcap($atts,$content=NULL) {
		$output='<span class="dropcap">'.strip_tags($content).'</span>';
		return $output;
	}

	/**
		Highlight
			@param $atts array
			@param $content string
			@public
	**/
	static function highlight($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'style'=>'1',
		), $atts) );
		if(!in_array($style,array('1','2')))
			$style='1';
		$output='<span class="highlight-'.$style.'">'.strip_tags($content).'</span>';
		return $output;
	}

	/**
		Pullquote
			@param $atts array
			@param $content string
			@public
	**/
	static function pullquote($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'align'=>'left',
		), $atts) );
		if(!in_array($align,array('left','right')))
			$align='left';
		$output='<span class="pullquote-'.$align.'">'.strip_tags($content).'</span>';
		return $output;
	}

	/**
		Tabs container and links
			@param $atts array
			@param $content string
			@public
	**/
	static function tabs($atts,$content=NULL) {
		extract(shortcode_atts(array(),$atts));
		self::$vars['tab_count']=1;
		$output='<div class="sc-tabs">'."\n";
		$output.='<ul class="sc-tabs-header">'."\n";
		$count=1;
		foreach($atts as $tab) {
			$output.='<li id="sc-tab'.$count.'"><a href="#sc-tabs-'.$count.'">'.$tab.'</a></li>'."\n";
			$count++;
		}
		$output.='</ul>'."\n";
		$output.='<div class="sc-tabs-body clearfix">'."\n";
		$output.=do_shortcode($content);
		$output.='</div>'."\n";
		$output.='</div>'."\n";
		// remove wp auto formatting - <br /> tags
		$output=str_replace(array('<br />'),'',$output);
		return $output;
	}

	/**
		Tab
			@param $atts array
			@param $content string
			@public
	**/
	static function tab($atts,$content=NULL) {
		extract(shortcode_atts(array(),$atts));
		$output='<div id="sc-tabs-'.self::$vars['tab_count'].'" class="sc-tab-single-box">'.do_shortcode($content).'</div>';
		self::$vars['tab_count']++;
		return $output;
	}

	/**
		Toggle
			@param $atts array
			@param $content string
			@public
	**/
	static function toggle($atts,$content=NULL) {
		extract( shortcode_atts( array(
			'title'=>'Enter A Title',
		), $atts) );
		$output='<div class="toggle-box">';
		$output.='<h4 class="toggle-title"><a href="#">'.$title.'</a></h4>';
		$output.='<div class="toggle-inner">'.do_shortcode($content).'</div>';
		$output.='</div>';
		return $output;
	}

}
