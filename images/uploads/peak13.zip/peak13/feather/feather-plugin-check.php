<?php

//! Feather Plugin Check
if(!defined('FEATHER_PATH')) {
	if(is_admin()) {
		add_thickbox(); // Required for the plugin install dialog.
		add_action('admin_notices','feather_admin_plugin_notice');
	} else {
		global $pagenow;
		// Exclude login,register pages
		$exclude=array('wp-login.php','wp-register.php');
		if(!in_array($pagenow,$exclude)) {
			wp_die('Please install/activate the required Feather plugin.');
		}
	}
}

//! Feather Plugin Notice
function feather_admin_plugin_notice() {
	$plugin_url=admin_url('plugin-install.php?tab=plugin-information&'.
		'plugin=feather&TB_iframe=true&width=640&height=517');
	$output='<div class="error fade">';
	$output.='<p>Peak : Please install/activate the Feather plugin. '.
		'<a href='.$plugin_url.'" class="thickbox onclick">Install Now</a></p>';
	$output.='</div>';
	// Display error
	echo $output;
}