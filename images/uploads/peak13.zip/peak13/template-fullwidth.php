<?php
/*
Template Name: Full-width
*/
?>


<?php get_header(); ?>

<div id="content" class="t-fullwidth">
<div id="content_inner" class="container_12">
		<div class="grid_12">
	<?php while(have_posts()): the_post(); ?>
			<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
				<header class="page">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header>
				<div class="text clearfix">
					<?php the_content(); ?>
					<div class="clear"></div>
					<?php edit_post_link(__('Edit'), ' &#183; ', ''); ?>
				</div>
			</article>
	<?php endwhile;?>
		</div>
</div>
</div>

<?php get_footer(); ?>