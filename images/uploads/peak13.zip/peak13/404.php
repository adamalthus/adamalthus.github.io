<?php get_header(); ?>

<div id="content">
<div id="content_inner" class="container_12">
	<div class="grid_12">
		<div class="text">
			<h1 style="margin-top: 80px; text-align: center;"><?php bandit::lang('404_heading'); ?></h1>
			<p style="text-align: center;"><?php bandit::lang('404_text'); ?></p>
		</div>
	</div>
</div>
</div>

<?php get_footer(); ?>