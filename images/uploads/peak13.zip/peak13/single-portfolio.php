<?php get_header(); ?>

<?php
// Load Single Portfolio Post Template
while(have_posts()): the_post();
	// Get post meta
	$meta=get_post_custom($post->ID);
	// Set template
	$template=TEMPLATEPATH.'/templates/portfolio-single-'.$meta['_bandit_portfolio_template'][0];
	// Is video template?
	if(isset($meta['_bandit_portfolio_video_template'][0]))
		$template.='-video';
	// Load template
	require_once($template.'.php');
endwhile;
?>

	</div><!--#content_inner-->
</div><!--#content-->

<?php get_footer(); ?>
