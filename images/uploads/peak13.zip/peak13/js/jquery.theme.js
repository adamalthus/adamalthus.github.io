jQuery(document).ready(function($) {

/*---------------------------------------------------------------------------*
 * Scroll to top
/*---------------------------------------------------------------------------*/
	$('#footer a.top,.sc-divider a').click(function() {
		$('html, body').animate({scrollTop:0},'slow');
		return false;
	});

/*---------------------------------------------------------------------------*
 * Menu fade
/*---------------------------------------------------------------------------*/
	$('.nav ul.sub-menu').hide();
	$('.nav li').hover( 
		function() {
			$(this).children('ul.sub-menu').slideDown('fast');
		}, 
		function() {
			$(this).children('ul.sub-menu').hide();
		}
	);
	
/*---------------------------------------------------------------------------*
 * Show/Hide Category List
/*---------------------------------------------------------------------------*/
	if($('.category-expand').length) {
		$('.format-icon').hover(
			function() {
				$(this).children('.category-expand').animate({width:'toggle'},'fast');
			},
			function() {
				$(this).children('.category-expand').hide();
			}
		);
	}

/*---------------------------------------------------------------------------*
 * Add alt-row styling to tables
/*---------------------------------------------------------------------------*/
	if($('.entry table').length) {
		$('.entry table tr:odd').addClass('alt-table-row');
	}

/*---------------------------------------------------------------------------*
 * jQuery UI Tabs
/*---------------------------------------------------------------------------*/
	// widget tabs
	if($('.widget_bandit_tabs').length) {
		$('.bandit_tabs').tabs({
			fx: {opacity:'show'}
		});
	}

	// content tabs
	if($('.sc-tabs').length) {
		$('.sc-tabs').tabs({
			fx: {opacity:'show'}
		});
	}

/*---------------------------------------------------------------------------*
 * Toggle Box
/*---------------------------------------------------------------------------*/
	if($('.toggle-box').length) {
		$('h4.toggle-title').click(function() {
			$(this).toggleClass('toggle-title-active')
			$(this).parent().find('.toggle-inner').toggle();
			return false;
		});
	}

/*---------------------------------------------------------------------------*
 * Like This
/*---------------------------------------------------------------------------*/
	if($('.like-count').length) {
		$('.like-count a').live('click',function() {
			var id = $(this).attr('id');
			id = id.split('like-');
			$.ajax({
				url: bandit.ajaxurl,
				type: "POST",
				dataType: 'json',
				data: { action : 'bandit_liked_ajax', id : id[1] },
				success:function(data) {
					if(true==data.success) {
						$('#like-'+data.postID).html('<i class="icon"></i> '+data.count);
						$('#like-'+data.postID).addClass('active');
					}
				}
			});
			return false;
		});
	}

/*---------------------------------------------------------------------------*
 * prettyPhoto
/*---------------------------------------------------------------------------*/
	if($('.prettyPhoto').length) {
		$("a[rel^='prettyPhoto']").prettyPhoto({
			default_width: 620,
			overlay_gallery: false,
			social_tools: ''
		});
	}

/*---------------------------------------------------------------------------*
 * AJAX Load More Items
/*---------------------------------------------------------------------------*/
	if($('#entry-load-more-link').length) {
		// variables
		var loadMoreLink = $('#entry-load-more-link');
		var maxPages = parseInt(loadMoreLink.attr('data-max'));
		var currentPage = 1;
		var nextLink = loadMoreLink.attr('data-src');
		// load more link click function
		loadMoreLink.click(function() {
			if(currentPage < maxPages) {
				currentPage++;
				$(this).text('Loading ...');
				$.get(nextLink+currentPage+' .item', function(data) {
					$(data).find('article').appendTo('#article_container');
					// Check if more pages
					if(currentPage < maxPages) {
						loadMoreLink.text('Load More');
					} else {
						loadMoreLink.hide();
					}
					// Reload prettyPhoto if needed
					if($('.prettyPhoto').length) {
						$("a[rel^='prettyPhoto']").prettyPhoto({
							default_width: 620,
							overlay_gallery: false,
							social_tools: ''
						});
					}
				});
			}
			return false;
		});
	}

});