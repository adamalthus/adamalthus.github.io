<div class="push"></div>
</div>
<!--END WRAPPER-->

<footer id="footer">
<div id="footer_inner" class="container_12 clearfix">
	<div class="grid_12">
		<?php wp_nav_menu(array('container'=>'nav','theme_location'=>'bandit_nav_footer',
				'menu_id'=>'menu-footer','menu_class'=>'links','fallback_cb'=>FALSE)); ?>
		<p>Copyright &copy; <?php echo date('Y').' '.get_bloginfo('site_name'); ?>. Powered by WordPress.</p>
		<ul class="smb clearfix">
			<?php bandit::social_media_link('twitter','li'); ?>
			<?php bandit::social_media_link('facebook','li'); ?>
			<?php bandit::social_media_link('flickr','li'); ?>
			<li class="rss"><a href="<?php bloginfo('rss2_url'); ?>">Subscribe</a></li>
		</ul>
		<a class="top" href="#"><?php bandit::lang('footer_back_to_top'); ?></a>
	</div>
</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>