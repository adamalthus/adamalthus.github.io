
<div id="sidebar" class="grid_4">
	<ul>
		<?php dynamic_sidebar('bandit_sidebar'); ?>
	</ul>
</div>