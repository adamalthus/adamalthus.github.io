<?php get_header(); ?>

<?php 
// get portfolio category info
$term=get_term_by('slug',get_query_var( 'term' ),get_query_var('taxonomy'));
// get portfolio category template
$template=bandit::get_theme_option('theme_portfolio_'.$term->slug);
$template=$template?$template:'1';
// get portfolio category num
$template_num=bandit::get_theme_option('theme_portfolio_'.$term->slug.'_num');
$template_num=$template_num?$template_num:'-1';
// get ajax nav option
$ajaxnav=bandit::get_theme_option('theme_portfolio_ajaxnav');
// portfolio loop
$args=array('post_type'=>'portfolio','portfolio_category'=>$term->slug,
	'posts_per_page'=>$template_num);
if('-1'!=$template_num) {
	$paged=get_query_var('page')?get_query_var('page'):1;
	$args['posts_per_page']=$template_num;
	$args['paged']=$paged;
}
$loop=new WP_Query($args);

function ieversion() {
  $match=preg_match('/MSIE ([0-9]\.[0-9])/',$_SERVER['HTTP_USER_AGENT'],$reg);
  if($match==0)
    return false;
  else
    return floatval($reg[1]);
}
$ie=(ieversion())?ieversion():10;
?>

<div id="content" class="t-portfolio<?php if($template=='11') { echo ' web'; } ?>">
	<div id="topcat">
		<div id="topcat_inner" class="container_12 clearfix">
			<div class="grid_12">
				<ul class="clearfix">
					<?php wp_list_categories(array('taxonomy'=>'portfolio_category','orderby'=>'name','title_li'=>'')); ?>
				</ul>
			</div>
		</div>
	</div><!--topcat-->
	<div id="topdesc">
		<div id="topdesc_inner" class="container_12 clearfix">
			<div class="grid_12 clearfix text">
				<?php if ($term->description): ?>
					<p class="catdesc"><?php echo $term->description; ?></p>
				<?php endif; ?>
			</div>
		</div>
	</div><!--topdesc-->
	<div id="content_inner" class="container_12 clearfix">
		<div id="article_container">
			<?php require_once(TEMPLATEPATH.'/templates/portfolio-'.$template.'.php'); ?>
		</div>

<?php if(bandit::get_theme_option('theme_portfolio_rewrite_category')!='') { $pagevar='?page='; } else { $pagevar='&page='; } ?>

<?php if($ajaxnav && $loop->max_num_pages>1 && 1==$paged && ($ie > 8)): ?>
<!-- AJAX NAVIGATION -->
<nav class="grid_12 entry-nav clearfix">
	<p><a id="entry-load-more-link" data-empty="No more items available." data-max="<?php echo $loop->max_num_pages; ?>" data-src="<?php echo get_term_link($term).$pagevar; ?>" href="#">Load More</a></p>
</nav>
<!-- END AJAX NAVIGATION -->
<?php endif; ?>


<?php if((!$ajaxnav && $loop->max_num_pages>1) || (1!=$paged && '0'!=$template_num) || ($ie < 9)): ?>
<!-- STANDARD NAVIGATION -->
<nav class="grid_12 entry-nav clearfix">
	<ul>
<?php if ($paged > 1): ?>
<?php $page_link=(($paged-1)!=1)?$pagevar.($paged-1):''; ?>
		<li class="prev left"><a href="<?php echo get_term_link($term).$page_link; ?>"><?php bandit::lang('post_nav_prev'); ?></a></li>
<?php endif; ?>

<?php if($paged < $loop->max_num_pages): ?>
		<li class="next right"><a href="<?php echo get_term_link($term).$pagevar.($paged+1); ?>"><?php bandit::lang('post_nav_next'); ?></a></li>
<?php endif; ?>
	</ul>
</nav>
<!-- END STANDARD NAVIGATION -->
<?php endif; ?>

	</div>
</div>

<?php get_footer(); ?>