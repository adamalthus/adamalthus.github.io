<?php
/*
Template Name: Front Page
*/

$meta=get_post_custom($post->ID);
?>

<?php get_header(); ?>

<div id="content" class="t-front">
<?php if(isset($meta['_bandit_front_intro_top'])): // FRONT INTRO TOP ?>
	<div id="topintro">
		<div id="topintro_inner" class="container_12 clearfix">
			<div class="grid_12">
				<h2><?php echo $meta['_bandit_front_intro_top'][0]; ?></h2>
			</div>
		</div>
	</div>
<?php endif; // END FRONT INTRO TOP ?>


<?php $images=bandit::get_post_images(); ?>
<?php if(!empty($images)): $imagecount=count($images); // GALLERY BLOCK ?>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$("#front-slider").slides({
			autoHeight: false,
			preload: true,
			generatePagination: false,
			effect: 'fade',
			crossfade: true,
			play: 10000
		});
	});
</script>

	<div id="topline">
		<div id="topline_inner" class="container_12 clearfix">
			<div class="grid_12 front-slider">

			<!--image block-->
			<div id="front-slider">		
				<div id="slider-prev" class="prev">Previous</div>
				<div id="slider-next" class="next">Next</div>
				<div class="slides_container">
				<?php foreach($images as $image): $imagelink=($image->post_excerpt!='')?$image->post_excerpt:NULL; ?>
				<?php $imagealt=$image->post_title; ?>
				<?php $image=bandit::vt_resize($image->ID,'','940','480',TRUE); ?>
					<div class="item">
						<?php if(isset($imagelink)): ?>
							<a href="<?php echo $imagelink; ?>"><img src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" alt="<?php echo $imagealt; ?>" /></a>
						<?php else: ?>
							<img src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" alt="<?php echo $imagealt; ?>" />
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
				</div>
				<div id="shadow">
					<ul class="pagination">
						<?php for($i=1;$i<=$imagecount;$i++): ?>
							<li><a href="#"><?php echo $i; ?></a></li>
						<?php endfor; ?>
					</ul>
				</div>
			</div>

			</div>
		</div>
	</div>
<?php endif; // END GALLERY BLOCK ?>

	<div id="content_inner" class="container_12 clearfix">
		
<?php if(isset($meta['_bandit_front_intro_bottom'])): // FRONT INTRO BOTTOM ?>
		<div class="grid_12" id="bottomintro_inner">
			<h2><?php echo $meta['_bandit_front_intro_bottom'][0]; ?></h2>
		</div>
<?php endif; // END FRONT INTRO BOTTOM ?>


<?php if(!isset($meta['_bandit_front_content_disable'])): // CONTENT BLOCK ?>
<?php if(isset($meta['_bandit_front_content_title'][0])): // CONTENT BLOCK TITLE ?>
		<div class="grid_12">
			<h4 class="dotted">
				<span><?php echo $meta['_bandit_front_content_title'][0]; ?></span>
			</h4>
		</div>
<?php endif; // END CONTENT BLOCK TITLE ?>

		<div id="front-blocks" class="clearfix">
<?php for($i=1;$i<=6;$i++): // CONTENT ITEMS ?>
<?php if(isset($meta['_bandit_front_content_block'.$i])): ?>
			<div class="grid_4">
				<?php echo $meta['_bandit_front_content_block'.$i][0]; ?>
			</div>
<?php endif; ?>
<?php endfor; // END CONTENT ITEMS ?>
		</div>
<?php endif; // END CONTENT BLOCK ?>


<?php if(!isset($meta['_bandit_front_portfolio_disable'])): // PORTFOLIO BLOCK ?>
		<div class="grid_12">
			<div id="front-btnblock" class="clearfix">
				<div>
					<h3><?php echo $meta['_bandit_front_portfolio_title'][0]; ?></h3>
					<p><?php echo $meta['_bandit_front_portfolio_desc'][0]; ?></p>
				</div>
				<a class="button-large" href="<?php if(isset($meta['_bandit_front_portfolio_link'][0])) { echo $meta['_bandit_front_portfolio_link'][0]; } ?>">
					<?php echo $meta['_bandit_front_portfolio_link_text'][0]; ?>
				</a>
			</div>
		</div>
<?php endif; // END PORTFOLIO BLOCK ?>


<?php if($meta['_bandit_front_blog_num'][0]!='none'): // BLOG BLOCK ?>
<?php if(isset($meta['_bandit_front_blog_title'][0])): ?>
		<div class="grid_12">
			<h4 class="dotted">
				<span><?php echo $meta['_bandit_front_blog_title'][0]; ?></span>
			</h4>
		</div>
<?php endif; ?>

		<div class="grid_12">
<?php 
	// Blog loop
	$blog=new WP_Query(array('posts_per_page'=>$meta['_bandit_front_blog_num'][0],'ignore_sticky_posts'=>1));
	// Blog counter
	$blogcount=1;
	// Loop through posts
	while($blog->have_posts()): $blog->the_post();
		// Post class
		$blogpostclass='';
		if((($blogcount-1)%3)==0)
			$blogpostclass=' alpha';
		elseif(($blogcount%3)==0)
			$blogpostclass=' omega';
?>
			<div class="grid_4<?php echo $blogpostclass; ?>">
				<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
					<div class="format-icon">
						<i class="icon"></i>
					</div>
					<header>
						<h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					</header>
					<ul class="entry-meta clearfix">
						<li class="published"><a href="<?php the_permalink(); ?>" title="Permalink for: <?php the_title(); ?>"><i class="icon"></i><?php bandit::time_ago(); ?></a></li>
						<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
							<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
						</li>
						<li class="comment-count"><a href="<?php comments_link(); ?>"><i class="icon"></i><?php comments_number('0','1','%'); ?></a></li>
					</ul>	
				</article>	
			</div>
<?php $blogcount++; ?>
<?php endwhile; ?>
		</div>
<?php endif; // END BLOG BLOCK ?>

	</div>
</div>

<?php get_footer(); ?>