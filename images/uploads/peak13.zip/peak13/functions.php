<?php 

//! Feather Plugin Check
require_once(TEMPLATEPATH.'/feather/feather-plugin-check.php');

/* --- Place custom functions below - do not edit the line above ---------- */

