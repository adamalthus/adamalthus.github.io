<?php get_header(); ?>

<div id="content">
<div id="content_inner" class="container_12">
	<div class="grid_8">
<?php while(have_posts()): the_post(); ?>
<?php //$iliked=BanditTheme::get_liked(); ?>

		<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
			<div class="format-icon">
				<i class="icon"></i>
				<div class="category-expand"><?php bandit::lang('post_meta_in'); ?> <?php the_category(', '); ?></div>
			</div>

			<?php if(get_post_format()) { get_template_part('post-formats'); } // POST FORMATS TEMPLATE ?>

			<header>
				<h1 class="entry-title"><?php the_title(); ?></h1>
			</header>

			<div class="text">
				<?php the_content(); ?>
				<div class="clear"></div>
				<?php wp_link_pages(array('before'=>'<div class="entry-page-links">'.bandit::get_lang('post_page_links'),'after'=>'</div>')); ?>
			</div>
			<?php the_tags('<div class="tags clearfix"><span>Tags:</span> ', ' ', '</div>'); ?>
			<ul class="entry-meta clearfix">
				<li class="published"><a href="<?php the_permalink(); ?>" title="Permalink for: <?php the_title(); ?>"><i class="icon"></i><?php bandit::time_ago(); ?></a></li>
				<li class="author"><i class="icon"></i><?php bandit::lang('post_meta_by'); ?> <?php the_author(); ?></li>
				<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
					<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
				</li>
				<?php edit_post_link('<i class="icon"></i>Edit', '<li class="edit">', '</li>'); ?>
			</ul>
		</article>

<?php if(bandit::comments_enabled() || have_comments()): ?>
		<div id="entry-comments">
			<?php comments_template(); ?>
		</div>
<?php endif; ?>
<?php endwhile;?>
	</div>

	<?php get_sidebar(); ?>
</div>
</div>

<?php get_footer(); ?>