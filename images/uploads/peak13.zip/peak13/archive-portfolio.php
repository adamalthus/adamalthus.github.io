<?php get_header(); ?>

<div id="content" class="t-portfolio">
	<div id="topcat">
		<div id="topcat_inner" class="container_12 clearfix">
			<div class="grid_12">
				<ul class="clearfix">
					<?php wp_list_categories(array('taxonomy'=>'portfolio_category','orderby'=>'name','title_li'=>'')); ?>
				</ul>
			</div>
		</div>
	</div>
	<div id="topdesc">
		<div id="topdesc_inner" class="container_12 clearfix">
			<div class="text">
				<h1 style="margin-top: 80px; text-align: center;"><?php bandit::lang('portfolio_heading'); ?></h1>
				<p style="text-align: center;"><?php bandit::lang('portfolio_desc'); ?></p>
			</div>
		</div>
	</div>
	<div id="content_inner" class="container_12 clearfix">
		
	</div>
</div>

<?php get_footer(); ?>