<?php
/*
Template Name: Widget-Sidebar Right
*/
?>

<?php get_header(); ?>

<div id="content" class="t-rightsidebar">
<div id="content_inner" class="container_12">
		<div class="grid_8">
	<?php while(have_posts()): the_post(); ?>
			<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
				<header class="page">
					<h1 class="entry-title"><?php the_title(); ?></h1>
				</header>
				<div class="text clearfix">
					<?php the_content(); ?>
					<div class="clear"></div>
					<?php edit_post_link(__('Edit'), ' &#183; ', ''); ?>
				</div>
			</article>

<?php if(bandit::comments_enabled() || have_comments()): ?>
		<div id="entry-comments">
			<?php comments_template(); ?>
		</div>
<?php endif; ?>
	<?php endwhile;?>
		</div>
	<?php get_sidebar(); ?>
</div>
</div>

<?php get_footer(); ?>