<?php get_header(); ?>

<div id="content">
<div id="content_inner" class="container_12">
	<div class="grid_8">
<?php while(have_posts()): the_post(); ?>
		<article id="entry-<?php the_ID(); ?>" <?php post_class('entry'); ?>>
			<div class="format-icon">
				<i class="icon"></i>
				<div class="category-expand"><?php bandit::lang('post_meta_in'); ?> <?php the_category(', '); ?></div>
			</div>
			<?php if(is_sticky()) { echo '<div class="sticky-icon"></div>'; } ?>

			<?php if(get_post_format()) { get_template_part('post-formats'); } // POST FORMATS TEMPLATE ?>

			<header>
				<h2 class="entry-title">
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
				</h2>
			</header>

			<div class="text">
				<?php the_content(bandit::get_lang('post_read_more')); ?>
				<?php wp_link_pages(array('before'=>'<div class="entry-page-links">'.bandit::get_lang('post_page_links'),'after'=>'</div>')); ?>
			</div>

			<ul class="entry-meta clearfix">
				<li class="published"><a href="<?php the_permalink(); ?>" title="Permalink for: <?php the_title(); ?>"><i class="icon"></i><?php bandit::time_ago(); ?></a></li>
				<li class="author"><i class="icon"></i><?php bandit::lang('post_meta_by'); ?> <?php the_author(); ?></li>
				<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
					<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
				</li>
				<li class="comment-count"><a href="<?php comments_link(); ?>"><i class="icon"></i> <?php comments_number('0','1','%'); ?> </a></li>
			</ul>
		</article>
<?php endwhile;?>

<?php get_template_part('nav-posts'); // POST NAV TEMPLATE ?>
	</div>

	<?php get_sidebar(); ?>
</div>
</div>

<?php get_footer(); ?>