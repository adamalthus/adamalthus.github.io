<?php
// Get category
$terms=array_values(get_the_terms($post->ID,'portfolio_category'));
?>
<div id="content" class="t-portfolio single style-2 video">

	<div id="topcat">
		<div id="topcat_inner" class="container_12 clearfix">
			<div class="grid_12">
				<ul class="clearfix">
					<li class="current-cat"><a class="back" href="<?php echo get_term_link($terms[0]); ?>"><?php bandit::lang('portfolio_button_goback'); ?></a></li>
				</ul>
			</div>
		</div>
	</div><!--topcat-->
	<div id="topdesc">
		<div id="topdesc_inner" class="container_12 clearfix">
			<div class="grid_12">	
			</div>
		</div>
	</div><!--topdesc-->

	<div id="content_inner" class="container_12 clearfix">

	<div class="grid_4 clearfix">
		<h2 class="entry-title"><?php the_title(); ?></h2>
		<div class="text clearfix up">
			<?php the_content(); ?>
		</div>
	</div>

	<article class="item grid_8 clearfix" id="item-<?php the_ID(); ?>">
	
		<div class="item-img">
			<div class="outer-center">
				<div class="inner-center">
<?php
if(isset($meta["_bandit_portfolio_video_url"])) {
	global $wp_embed;
	$video = $wp_embed->run_shortcode('[embed width="620"]'.$meta['_bandit_portfolio_video_url'][0].'[/embed]');
	echo $video;
} elseif(isset($meta['_bandit_portfolio_video_embed_code'][0])) {
		echo $meta['_bandit_portfolio_video_embed_code'][0];
}
?>
				</div>
			</div>
		</div>

		<div class="item-content clearfix">
			<ul class="entry-meta clearfix">
				<li class="time"><i class="icon"></i><?php the_time('F j, Y'); ?></li>
				<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
					<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
				</li>
				<?php edit_post_link('<i class="icon"></i>Edit', '<li class="edit">', '</li>'); ?>
			</ul>
		</div>
	</article>

