<?php
//get total images
$images=bandit::get_post_images();
// get category
$terms=array_values(get_the_terms($post->ID,'portfolio_category'));
?>

<div id="content" class="t-portfolio single style-3">

	<div id="topcat">
		<div id="topcat_inner" class="container_12 clearfix">
			<div class="grid_12">
				<ul class="clearfix">
					<li class="current-cat"><a class="back" href="<?php echo get_term_link($terms[0]); ?>"><?php bandit::lang('portfolio_button_goback'); ?></a></li>
				</ul>
			</div>
		</div>
	</div><!--topcat-->
	<div id="topdesc">
		<div id="topdesc_inner" class="container_12 clearfix">
			<div class="grid_12">
			</div>
		</div>
	</div><!--topdesc-->

	<div id="content_inner" class="container_12 clearfix">
	
	<article class="item grid_8 clearfix" id="item-<?php the_ID(); ?>">
<?php if(count($images) > 1): ?>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$(".slider-gallery").slides({
			autoHeight: true,
			preload: true,
			generatePagination: true,
			effect: 'fade',
			crossfade: true,
			play: 15000
		});
	});
</script>

		<div class="item-img">
			<div class="slider-gallery">
				<div class="slides_container clearfix">
					<?php foreach($images as $image): ?>
						<div>
							<?php $image620=wp_get_attachment_image_src($image->ID,'post-format-620'); ?>
							<img src="<?php echo $image620[0]; ?>" width="<?php echo $image620[1]; ?>" height="<?php echo $image620[2]; ?>" alt="<?php echo $image->post_title; ?>" />
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

<?php else: ?>
		<div class="item-img">
			<?php the_post_thumbnail('post-format-620'); ?>
		</div>
<?php endif;?>

		<div class="item-content clearfix">
			<ul class="entry-meta clearfix">
				<li class="time"><i class="icon"></i><?php the_time('F j, Y'); ?></li>
				<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
					<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
				</li>
				<?php edit_post_link('<i class="icon"></i>Edit', '<li class="edit">', '</li>'); ?>
			</ul>
		</div>
	</article>

	<div class="grid_4 clearfix">
		<h2 class="entry-title"><?php the_title(); ?></h2>
		<div class="text clearfix up">
			<?php the_content(); ?>
		</div>
	</div>

	
	