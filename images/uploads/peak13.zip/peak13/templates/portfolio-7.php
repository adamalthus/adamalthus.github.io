<?php while($loop->have_posts()): $loop->the_post(); ?>

<?php
// image size
$img_w='460';
$img_h='240';
// dynamic post image resizing
$image_id=get_post_thumbnail_id();
// Get custom thumbnail option
$customthumb=get_post_meta($post->ID,'_bandit_portfolio_custom_thumbnail',TRUE);
// Get timthumb option
$timthumb=get_post_meta($post->ID,'_bandit_portfolio_timthumb',TRUE);
// Get image
if($image_id) {
	if($customthumb) {
		$image['url']=$customthumb;
	} elseif($timthumb) {
		$image=bandit::timthumb($image_id,$post->ID,$img_w,$img_h);
	} else {
		$image=bandit::dynamic_resize($image_id,'',$img_w,$img_h,TRUE);
	}
	$image['alt']=get_the_title($image_id);
} else {
	$image['url']=get_bloginfo('template_url').'/img/blank.png';
	$image['alt']='image placeholder';
}

$item_link=get_permalink();
$pp_rel='';
$pp_class='';
$lightbox=bandit::get_theme_option('theme_portfolio_'.$term->slug.'_lightbox');
if($lightbox && $image_id) {
	$item_620_image=wp_get_attachment_image_src($image_id,'large');
	$item_link=$item_620_image[0];
	$pp_rel='rel="prettyPhoto[pp_gal]"';
	$pp_class='prettyPhoto';
	// Video URL
	$video_url=get_post_meta($post->ID,'_bandit_portfolio_video_url',TRUE);
	// Video Embed Code
	$video_embed_code=get_post_meta($post->ID,'_bandit_portfolio_video_embed_code',TRUE);
	if($video_url || $video_embed_code) {
		$item_link='#video-'.get_the_ID();
	}
}
?>

			<article class="item grid_6 clearfix <?php echo $pp_class; ?>" id="item-<?php the_ID(); ?>">
				<div class="item-img">
					<a href="<?php echo $item_link; ?>" title="<?php the_title(); ?>" <?php echo $pp_rel; ?>>
						<img src="<?php echo $image['url']; ?>" width="<?php echo $img_w; ?>" height="<?php echo $img_h; ?>" alt="<?php echo $image['alt']; ?>" />
						<span class="icon"></span>
					</a>
				</div>
				<div class="item-content clearfix">
					<p class="item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
					<ul class="entry-meta clearfix">
						<li class="time"><i class="icon"></i><?php the_time('F j, Y'); ?></li>
						<li class="like-count"><a id="like-<?php the_ID(); ?>" href="#" <?php bandit::liked_class(); ?>>
							<i class="icon"></i><?php bandit::post_liked_count(); ?></a>
						</li>
					</ul>
				</div>
<?php
if($lightbox && ($video_url || $video_embed_code)) {
	echo '<div id="video-'.get_the_ID().'" class="pp_video">';
	if(isset($video_url)) {
		global $wp_embed;
		$video = $wp_embed->run_shortcode('[embed width="620"]'.$video_url.'[/embed]');
		echo $video;
	} elseif(isset($video_embed_code)) {
			echo $video_embed_code;
	}
	echo '</div>';
}
?>
			</article>
<?php endwhile; ?>