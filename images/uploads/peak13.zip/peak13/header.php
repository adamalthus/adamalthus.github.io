<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width">

<title><?php bandit::title(); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />

<?php bandit::stylesheets(); ?>
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">

<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<!--BEGIN WRAPPER-->
<div class="wrapper">

<header id="header">
<div id="header_inner" class="container_12 clearfix">
	<div class="grid_12">
		<?php bandit::site_name(); ?>
		<?php bandit::site_desc(); ?>

		<?php wp_nav_menu(array('container'=>'nav','container_id'=>'nav','theme_location'=>'bandit_nav_header',
				'menu_id'=>'menu-header','menu_class'=>'nav','fallback_cb'=>FALSE)); ?>
	</div>
</div>
</header>